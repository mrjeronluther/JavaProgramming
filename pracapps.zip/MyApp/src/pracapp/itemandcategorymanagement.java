package pracapp;

import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerModel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import com.mysql.cj.jdbc.Blob;

public class itemandcategorymanagement extends JFrame{

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;
    private JTextField txtSearch;
    private JLabel lblItem;
    private JTextField textField_1;
    private JLabel lblCategory;
    private JTextField textField_2;
    private JButton btnAdd;
    private JButton btnModify;
    private JButton btnDelete;
    private JLabel lblDescription;
    private JTextField textField_3;
    private JLabel lblQuantity;
    private JTextField textField_4;
    private JLabel lblPrice;
    private JTextField textField_5;
    private DefaultTableModel tableModel;
    private Connection conn;
   
    private JLabel lblNewLabel;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private JTextField textField;
    private JTextField textField_6;
    private JTextField textField_7;
    private JTextField textField_8;
    private JTextField textField_9;
    private JButton btnNewButton;
    private JLabel lblDeliveryDate;
    private JLabel lblExpiryDate;
    private JSpinner deliveryDateSpinner;
    private JSpinner expiryDateSpinner;
    private JTextField textField_10;
    private JTextField textField_11;
    private JLabel imagePreviewLabel; 
    private JButton btnAddImage;
    private byte[] selectedImageBytes = null; // Initialize it to null
    private JLabel imagePreviewLabel_1;
    
    private JTable table = new JTable(tableModel);


    
    
    
    private Image scaleAndCropImage(Image originalImage, int desiredWidth, int desiredHeight) {
        int originalWidth = originalImage.getWidth(null);
        int originalHeight = originalImage.getHeight(null);
        
        double scaleWidth = (double) desiredWidth / originalWidth;
        double scaleHeight = (double) desiredHeight / originalHeight;
        double scaleFactor = Math.max(scaleWidth, scaleHeight);

        int newWidth = (int) (originalWidth * scaleFactor);
        int newHeight = (int) (originalHeight * scaleFactor);

        // Create a new image with the desired size
        BufferedImage scaledImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = scaledImage.createGraphics();

        // Draw the original image to the scaled image
        g.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
        g.dispose();

        // Crop the scaled image to the desired dimensions
        int x = (newWidth - desiredWidth) / 2;
        int y = (newHeight - desiredHeight) / 2;
        BufferedImage croppedImage = scaledImage.getSubimage(x, y, desiredWidth, desiredHeight);

        return croppedImage;
    }

    

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    itemandcategorymanagement frame = new itemandcategorymanagement();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static BufferedImage resizeAndCropImage(Image originalImage, int width, int height) {
        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        bufferedImage.getGraphics().drawImage(originalImage, 0, 0, width, height, null);
        return bufferedImage;
    }

    public itemandcategorymanagement () {
        setResizable(false);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setBounds(100, 100, 925, 501);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblCategoryManagement = new JLabel("ITEM/CATEGORY MANAGEMENT");
        lblCategoryManagement.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblCategoryManagement.setBounds(339, 0, 301, 48);
        contentPane.add(lblCategoryManagement);

        txtSearch = new JTextField();
        txtSearch.setBounds(619, 59, 268, 20);
        contentPane.add(txtSearch);
        txtSearch.setColumns(10);

        lblItem = new JLabel("ITEM:");
        lblItem.setBounds(23, 67, 46, 14);
        contentPane.add(lblItem);

        textField_1 = new JTextField();
        textField_1.setBounds(119, 59, 119, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        lblCategory = new JLabel("CATEGORY:");
        lblCategory.setBounds(20, 90, 78, 14);
        contentPane.add(lblCategory);

        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(119, 87, 119, 20);
        contentPane.add(textField_2);
        
     // JSpinner for Delivery Date
        SpinnerModel deliveryDateModel = new SpinnerDateModel(new Date(), null, null, Calendar.DAY_OF_MONTH);
        deliveryDateSpinner = new JSpinner(deliveryDateModel);
        deliveryDateSpinner.setBounds(119, 222, 119, 20);
        contentPane.add(deliveryDateSpinner);

        // JSpinner for Expiry Date
        SpinnerModel expiryDateModel = new SpinnerDateModel(new Date(), null, null, Calendar.DAY_OF_MONTH);
        expiryDateSpinner = new JSpinner(expiryDateModel);
        expiryDateSpinner.setBounds(119, 253, 119, 20);
        contentPane.add(expiryDateSpinner);
           
        
        // Create a JLabel to display the image preview
        JLabel imagePreviewLabel = new JLabel();
        imagePreviewLabel.setBounds(108, 284, 129, 93);
        Border border = BorderFactory.createLineBorder(Color.BLACK);
        imagePreviewLabel.setBorder(border);
        contentPane.add(imagePreviewLabel);
        btnAddImage = new JButton("Add Image");
        btnAddImage.setFont(new Font("Tahoma", Font.PLAIN, 10));
        btnAddImage.setBounds(10, 332, 88, 23);
        contentPane.add(btnAddImage);
        btnAddImage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Choose an Image");
                fileChooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "gif"));

                int result = fileChooser.showOpenDialog(null);

                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    
                    // Check if the file size is larger than 8MB (8 * 1024 * 1024 bytes)
                    // Check if the file size is larger than 8MB (20480 20 kilobytes)
                    if (selectedFile.length() > 20480) {
                        JOptionPane.showMessageDialog(null, "The selected file is too large. Please select an image smaller than 20kb.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    String fileName = selectedFile.getName();
                    String extension = fileName.substring(fileName.lastIndexOf(".") + 1);

                    // Check if the file extension is allowed
                    if ("jpg".equalsIgnoreCase(extension) || "png".equalsIgnoreCase(extension)) {
                        try {
                            // Read the selected image file
                            BufferedImage originalImage = ImageIO.read(selectedFile);

                            // Get the size of the imagePreviewLabel
                            int labelWidth = imagePreviewLabel.getWidth();
                            int labelHeight = imagePreviewLabel.getHeight();

                            // Create a scaled version of the original image
                            Image scaledImage = originalImage.getScaledInstance(labelWidth, labelHeight, Image.SCALE_SMOOTH);

                            // Create an ImageIcon from the scaled image
                            ImageIcon icon = new ImageIcon(scaledImage);

                            // Set the icon on the imagePreviewLabel
                            imagePreviewLabel.setIcon(icon);

                            // Now set the selectedImageBytes
                            InputStream inputStream = new FileInputStream(selectedFile);
                            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                            byte[] buffer = new byte[1024];
                            int bytesRead;
                            while ((bytesRead = inputStream.read(buffer)) != -1) {
                                outputStream.write(buffer, 0, bytesRead);
                            }
                            selectedImageBytes = outputStream.toByteArray();
                            
                            // Close the input stream
                            inputStream.close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    } else {
                        // Display an error message for unsupported file format
                        JOptionPane.showMessageDialog(null, "Only JPG and PNG files are allowed.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });


        btnAdd = new JButton("ADD");
        btnAdd.setBounds(78, 409, 89, 23);
        contentPane.add(btnAdd);
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String Item = textField_1.getText();
                String Category = textField_2.getText();
                String Description = textField_3.getText();
                String Quantity = textField_4.getText();
                String Price = textField_5.getText();

                // Retrieve the selected delivery date
                Date deliveryDate = (Date) deliveryDateSpinner.getValue();
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
                String Deli = dateFormat.format(deliveryDate);

                // Retrieve the selected expiry date
                Date expiryDate = (Date) expiryDateSpinner.getValue();
                String Exp = dateFormat.format(expiryDate);

                if (Item.isEmpty() || Category.isEmpty() || Description.isEmpty() || Quantity.isEmpty() || Price.isEmpty() || Deli.isEmpty() || Exp.isEmpty() || selectedImageBytes == null) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields and select an image before adding an item.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        String url = "jdbc:mysql://127.0.0.1:3306/javalogin";
                        String user = "root";
                        String password = "";

                        Connection conn = DriverManager.getConnection(url, user, password);

                        // Insert the image data into a new record
                        String insertSql = "INSERT INTO itemngmnt (Item, Category, Description, Quantity, Price, DeliveryDate, ExpiryDate, Image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                        PreparedStatement preparedStatement = conn.prepareStatement(insertSql);
                        preparedStatement.setString(1, Item);
                        preparedStatement.setString(2, Category);
                        preparedStatement.setString(3, Description);
                        preparedStatement.setString(4, Quantity);
                        preparedStatement.setString(5, Price);
                        preparedStatement.setString(6, Deli);
                        preparedStatement.setString(7, Exp);

                        // Create an input stream from the selected image bytes
                        ByteArrayInputStream imageStream = new ByteArrayInputStream(selectedImageBytes);

                        // Set the image data as a binary stream
                        preparedStatement.setBinaryStream(8, imageStream, selectedImageBytes.length);

                        int rowsAffected = preparedStatement.executeUpdate();

                        if (rowsAffected > 0) {
                        	JOptionPane.showMessageDialog(null, "Added Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                        	imagePreviewLabel.setIcon(null);
                        	 textField_1.setText(""); 
                             textField_2.setText("");  
                             textField_3.setText(""); 
                             textField_4.setText("");  
                             textField_5.setText("");  
                        }

                        preparedStatement.close();
                        conn.close();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                    // Fetch and display registered items or categories
                    displayRegisteredItems();
                }
            }
        });
   


        btnModify = new JButton("SAVE");
        btnModify.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 if (textField.getText().isEmpty() || textField_6.getText().isEmpty() || textField_7.getText().isEmpty() || textField_8.getText().isEmpty() || textField_9.getText().isEmpty() || textField_10.getText().isEmpty() || textField_11.getText().isEmpty() ) {
                     JOptionPane.showMessageDialog(null, "Please fill in all fields before saving.", "Error", JOptionPane.ERROR_MESSAGE);
                 } else {
                     int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to save the changes?", "Confirm Save", JOptionPane.YES_NO_OPTION);
                     if (confirm == JOptionPane.YES_OPTION) {
                         saveChangesToDatabase();
                     }
                 }
        	}
        	
        });
        btnModify.setBounds(275, 428, 89, 23);
        contentPane.add(btnModify);

        btnDelete = new JButton("DELETE");
        btnDelete.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String ItemToDelete = (String) tableModel.getValueAt(selectedRow, 0);
                    int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the selected user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        deleteFromDatabase(ItemToDelete);
                      
                        textField.setText("");
                        textField_6.setText("");
                        textField_7.setText("");
                        textField_8.setText("");
                        textField_9.setText("");
                        textField_10.setText("");
                        textField_11.setText("");
                        tableModel.removeRow(selectedRow);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a Item to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                
        		
                }
        	}
        });
        
        
        btnDelete.setBounds(393, 428, 89, 23);
        contentPane.add(btnDelete);

        lblDescription = new JLabel("SUPPLIER:");
        lblDescription.setBounds(23, 115, 104, 14);
        contentPane.add(lblDescription);

        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(119, 118, 119, 34);
        contentPane.add(textField_3);

        lblQuantity = new JLabel("QUANTITY:");
        lblQuantity.setBounds(20, 166, 78, 14);
        contentPane.add(lblQuantity);

        textField_4 = new JTextField();
        textField_4.setColumns(10);
        textField_4.setBounds(119, 163, 119, 20);
        contentPane.add(textField_4);
        
        textField_4.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE))) {
                    e.consume(); 
                }
            }
        });
           

        lblPrice = new JLabel("PRICE:");
        lblPrice.setBounds(23, 197, 78, 14);
        contentPane.add(lblPrice);

        textField_5 = new JTextField();
        textField_5.setColumns(10);
        textField_5.setBounds(119, 194, 119, 20);
        contentPane.add(textField_5);
        
        textField_5.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!(Character.isDigit(c) || (c == '.') || (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE))) {
                    e.consume(); 
                }
            }
        });
            

     // Assuming your JTable is named 'table' and the row height you want is 30 pixels
        table.setRowHeight(50);

        // Create a JScrollPane to hold the JTable
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(248, 90, 639, 243);
        contentPane.add(scrollPane);


        table = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        scrollPane.setViewportView(table);

        // Create the JTable and set the table model
        tableModel = new DefaultTableModel();
        table.setModel(tableModel); // Set the table model to the existing table

        // Initialize the table model
        tableModel.addColumn("Item");
        tableModel.addColumn("Category");
        tableModel.addColumn("Description");
        tableModel.addColumn("Quantity");
        tableModel.addColumn("Price");
        tableModel.addColumn("DeliveryDate");
        tableModel.addColumn("ExpiryDate");
        tableModel.addColumn("ItemImage");
        // Create a TableRowSorter for the tableModel
        rowSorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(rowSorter);

        lblNewLabel = new JLabel("SEARCH HERE:");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        lblNewLabel.setBounds(536, 62, 73, 14);
        contentPane.add(lblNewLabel);

        // Add a DocumentListener to the search bar's document
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                filterItems();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                filterItems();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                filterItems();
            }

            private void filterItems() {
                String text = txtSearch.getText();
                if (text.trim().isEmpty()) {
                    // If the search text is empty, show all rows
                    rowSorter.setRowFilter(null);
                } else {
                    // Use a RowFilter to show only rows that match the search text
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
        });

        // Establish a database connection
        try {
            String url = "jdbc:mysql://127.0.0.1:3306/javalogin";
            String user = "root";
            String password = "";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        displayRegisteredItems();
    }
    class ImageRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (value instanceof ImageIcon) {
                JLabel label = new JLabel((ImageIcon) value);
                label.setHorizontalAlignment(JLabel.CENTER);
                return label;
            }
            return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        }
    }

    private void displayRegisteredItems() {
        try {
            String sql = "SELECT Item, Category, Description, Quantity, Price, DeliveryDate, ExpiryDate, Image FROM itemngmnt";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String item = resultSet.getString("Item");
                String category = resultSet.getString("Category");
                String description = resultSet.getString("Description");
                String quantity = resultSet.getString("Quantity");
                String price = resultSet.getString("Price");
                String deli = resultSet.getString("DeliveryDate");
                String expi = resultSet.getString("ExpiryDate");
                java.sql.Blob imageBlob = resultSet.getBlob("Image"); // Replace "ImageColumn" with your actual column name

                // Convert the BLOB data to an ImageIcon
                ImageIcon imageIcon = null;
                if (imageBlob != null) {
                    try (InputStream inputStream = imageBlob.getBinaryStream()) {
                        BufferedImage image = ImageIO.read(inputStream);
                        if (image != null) {
                            imageIcon = new ImageIcon(image);
                        }
                    }
                }
                

                // Add a custom cell renderer to display the ImageIcon as an image
                int imageColumnIndex = 7; // Replace with the actual column index of the "Image" column
                table.getColumnModel().getColumn(imageColumnIndex).setCellRenderer(new ImageRenderer());

                // Add the row to the table model
                tableModel.addRow(new Object[]{item, category, description, quantity, price, deli, expi, imageIcon});
            }

            resultSet.close();
            preparedStatement.close();
        } catch (SQLException | IOException ex) {
            ex.printStackTrace();
        }
   
        textField = new JTextField();
        textField.setBounds(248, 344, 135, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_6 = new JTextField();
        textField_6.setColumns(10);
        textField_6.setBounds(393, 344, 135, 20);
        contentPane.add(textField_6);

        textField_7 = new JTextField();
        textField_7.setColumns(10);
        textField_7.setBounds(536, 344, 135, 20);
        contentPane.add(textField_7);

        textField_8 = new JTextField();
        textField_8.setColumns(10);
        textField_8.setBounds(247, 375, 135, 20);
        contentPane.add(textField_8);

        textField_9 = new JTextField();
        textField_9.setColumns(10);
        textField_9.setBounds(393, 375, 135, 20);
        contentPane.add(textField_9);        
    
        btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
           
                	ADMINPage frame = new ADMINPage();
					frame.setVisible(true);
					dispose();
            }
        });
             
    
        
        btnNewButton.setBounds(0, 0, 69, 23);
        contentPane.add(btnNewButton);
        
        lblDeliveryDate = new JLabel("DELIVERY DATE:");
        lblDeliveryDate.setBounds(20, 225, 107, 14);
        contentPane.add(lblDeliveryDate);
        
        lblExpiryDate = new JLabel("EXPIRY DATE:");
        lblExpiryDate.setBounds(20, 256, 107, 14);
        contentPane.add(lblExpiryDate);
        
        textField_10 = new JTextField();
        textField_10.setColumns(10);
        textField_10.setBounds(393, 406, 135, 20);
        contentPane.add(textField_10);
        
        textField_11 = new JTextField();
        textField_11.setColumns(10);
        textField_11.setBounds(248, 406, 135, 20);
        contentPane.add(textField_11);
        
        JButton btnNewButton_1 = new JButton("Add Image");
        btnNewButton_1.setBounds(9, 332, 89, 23);
        contentPane.add(btnNewButton_1);
        
        imagePreviewLabel_1 = new JLabel();
        imagePreviewLabel_1.setBounds(718, 344, 157, 107);
        contentPane.add(imagePreviewLabel_1);
        
        int imageColumnIndex = 7;
     // Add a ListSelectionListener to the table
        ListSelectionModel selectionModel = table.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();

                    // Clear the imagePreviewLabel_1 at the beginning
                    imagePreviewLabel_1.setIcon(null);

                    if (selectedRow != -1) {
                        // Retrieve data from the selected row
                        String item = (String) tableModel.getValueAt(selectedRow, 0);
                        String category = (String) tableModel.getValueAt(selectedRow, 1);
                        String description = (String) tableModel.getValueAt(selectedRow, 2);
                        String quantity = (String) tableModel.getValueAt(selectedRow, 3);
                        String price = (String) tableModel.getValueAt(selectedRow, 4);
                        String deli = (String) tableModel.getValueAt(selectedRow, 5);
                        String expi = (String) tableModel.getValueAt(selectedRow, 6);
                        ImageIcon selectedImage = (ImageIcon) tableModel.getValueAt(selectedRow, imageColumnIndex);

                        if (selectedImage != null) {
                            // Get the original image from the ImageIcon
                            Image originalImage = selectedImage.getImage();

                            // Get the size of the imagePreviewLabel
                            int labelWidth = imagePreviewLabel_1.getWidth();
                            int labelHeight = imagePreviewLabel_1.getHeight();

                            // Create a scaled and cropped version of the original image
                            Image scaledAndCroppedImage = scaleAndCropImage(originalImage, labelWidth, labelHeight);

                            // Create an ImageIcon from the scaled and cropped image
                            ImageIcon croppedImageIcon = new ImageIcon(scaledAndCroppedImage);

                            // Set the cropped image in imagePreviewLabel_1
                            imagePreviewLabel_1.setIcon(croppedImageIcon);
                        }

                        // Populate the text fields with the selected data
                        textField.setText(item);
                        textField_6.setText(category);
                        textField_7.setText(description);
                        textField_8.setText(quantity);
                        textField_9.setText(price);
                        textField_10.setText(deli);
                        textField_11.setText(expi);
                    }
                }
            }
        });
    }

        public void displayRegisteredItems1() {
            try {
                String sql = "SELECT Item, Category, Description, Quantity, Price, DeliveryDate, ExpiryDate FROM itemngmnt";
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    String Item = resultSet.getString("Item");
                    String Category = resultSet.getString("Category");
                    String Description = resultSet.getString("Description");
                    String Quantity = resultSet.getString("Quantity");
                    String Price = resultSet.getString("Price");
                    String Del = resultSet.getString("DeliveryDate");
                    String Exp = resultSet.getString("ExpiryDate");

                    tableModel.addRow(new Object[]{Item, Category, Description, Quantity, Price, Del, Exp});
                }

                // Close resources
                resultSet.close();
                preparedStatement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void saveChangesToDatabase() {
            try {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String newitem = textField.getText();
                    String newcat = textField_6.getText();
                    String newdes = textField_7.getText();
                    String newqty = textField_8.getText();
                    String newprc = textField_9.getText();
                    String newdel = textField_10.getText();
                    String newexp = textField_11.getText();

                    String ItemToUpdate = (String) tableModel.getValueAt(selectedRow, 0);

                    // Update user information in the database
                    String updateSql = "UPDATE itemngmnt SET Item = ?, Category = ?, Description = ?, Quantity = ?, Price = ?, DeliveryDate = ?, ExpiryDate = ? WHERE Item = ?";
                    PreparedStatement updateStatement = conn.prepareStatement(updateSql);
                    updateStatement.setString(1, newitem);
                    updateStatement.setString(2, newcat);
                    updateStatement.setString(3, newdes);
                    updateStatement.setString(4, newqty);
                    updateStatement.setString(5, newprc);
                    updateStatement.setString(6, newdel);
                    updateStatement.setString(7, newexp);
                    updateStatement.setString(8, ItemToUpdate);

                    int updatedRows = updateStatement.executeUpdate();

                    if (updatedRows != 1) {
                        // If an update fails, show an error message
                        JOptionPane.showMessageDialog(null, "Failed to save changes to the database.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }


        
                // Update the table with the new values
                tableModel.setValueAt(newitem, selectedRow, 0);
                tableModel.setValueAt(newcat, selectedRow, 1);
                tableModel.setValueAt(newdes, selectedRow, 2);
                tableModel.setValueAt(newqty, selectedRow, 3);
                tableModel.setValueAt(newprc, selectedRow, 4);
                tableModel.setValueAt(newdel, selectedRow, 5);
                tableModel.setValueAt(newexp, selectedRow, 6);

                // If all updates are successful
                JOptionPane.showMessageDialog(null, "Changes saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

              
                textField.setText("");    
                textField_6.setText("");    
                textField_7.setText("");    
                textField_8.setText("");
                textField_9.setText("");
                textField_10.setText("");
                textField_11.setText("");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public static void main1(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    itemandcategorymanagement frame = new itemandcategorymanagement();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

private void deleteFromDatabase(String Item) {
    try {
        String deleteSql = "DELETE FROM itemngmnt WHERE Item = ?";
        PreparedStatement deleteStatement = conn.prepareStatement(deleteSql);
        deleteStatement.setString(1, Item);
        int deletedRows = deleteStatement.executeUpdate();

        if (deletedRows != 1) {
            // Handle the case where the user was not deleted successfully
            JOptionPane.showMessageDialog(null, "Failed to delete user from the database.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            // Deletion was successful
            JOptionPane.showMessageDialog(null, "User deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    
}

public byte[] getSelectedImageBytes() {
	return selectedImageBytes;
}
}