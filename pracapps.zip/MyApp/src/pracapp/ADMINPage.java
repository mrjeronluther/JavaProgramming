package pracapp;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ADMINPage extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ADMINPage frame = new ADMINPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ADMINPage() {
		setResizable(false);

		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 737, 488);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAdminAccount = new JLabel("ADMIN ACCOUNT");
		lblAdminAccount.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAdminAccount.setBounds(299, 35, 156, 31);
		contentPane.add(lblAdminAccount);
		
		JButton btnNewButton = new JButton("USER MANAGEMENT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 USERRegistration frame = new USERRegistration();
                 frame.setVisible(true);
                 dispose();
			}
		});
		btnNewButton.setBounds(38, 109, 173, 45);
		contentPane.add(btnNewButton);
		
		JButton btnCategoryManagement = new JButton("ITEM/CATEGORY MANAGEMENT");
		btnCategoryManagement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  itemandcategorymanagement frame = new itemandcategorymanagement();
                  frame.setVisible(true);
                dispose();
			}
			
			
		});
		btnCategoryManagement.setBounds(256, 109, 227, 45);
		contentPane.add(btnCategoryManagement);
		
		JButton btnReporting = new JButton("REPORTING");
		btnReporting.setBounds(538, 109, 173, 45);
		contentPane.add(btnReporting);
		
		JButton btnNewButton_1 = new JButton("LOGOUT");
		btnNewButton_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure you want to log out?", "Confirmation", JOptionPane.YES_NO_OPTION);
		        
		        if (dialogResult == JOptionPane.YES_OPTION) {
		            Login frame = new Login();
		            frame.setVisible(true);
		            dispose(); 
		        }
		    }
		});

		btnNewButton_1.setBounds(635, 0, 86, 23);
		contentPane.add(btnNewButton_1);
	}

	
	


}




