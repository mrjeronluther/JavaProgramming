package pracapp;

import java.awt.EventQueue;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;

public class USERRegistration extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private Connection conn;
    private JTextField textField_3;
  

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    USERRegistration frame = new USERRegistration();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public USERRegistration() {
    	setResizable(false);

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setBounds(100, 100, 471, 326);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblUserRegistration = new JLabel("USER REGISTRATION");
        lblUserRegistration.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblUserRegistration.setBounds(131, 11, 195, 31);
        contentPane.add(lblUserRegistration);

        JLabel lblNewLabel = new JLabel("USERNAME");
        lblNewLabel.setBounds(10, 83, 77, 14);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("PASSWORD");
        lblNewLabel_1.setBounds(10, 120, 77, 14);
        contentPane.add(lblNewLabel_1);

        textField = new JTextField();
        textField.setBounds(97, 80, 143, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setBounds(97, 117, 143, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("FULLNAME");
        lblNewLabel_2.setBounds(10, 159, 77, 14);
        contentPane.add(lblNewLabel_2);

        textField_2 = new JTextField();
        textField_2.setBounds(97, 156, 143, 20);
        contentPane.add(textField_2);
        textField_2.setColumns(10);
        
        JLabel lblNewLabel_2_1 = new JLabel("POSITION");
        lblNewLabel_2_1.setBounds(10, 195, 77, 14);
        contentPane.add(lblNewLabel_2_1);
        
        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(97, 192, 143, 20);
        contentPane.add(textField_3);
        
        JLabel lblNewLabel_2_1_1 = new JLabel("");
        lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
        lblNewLabel_2_1_1.setForeground(new Color(255, 0, 0));
        lblNewLabel_2_1_1.setBounds(97, 211, 160, 14);
        contentPane.add(lblNewLabel_2_1_1);
        
        textField_3.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                String currentText = textField_3.getText();
                
                if (currentText.length() >= 1 || (!((c >= '0' && c <= '1') || c == '\b')) ) {
                    e.consume(); // Prevent the character from being entered
                
                    lblNewLabel_2_1_1.setText("1=ADMIN and 0=USER"); // Set error message
                } else {
                	lblNewLabel_2_1_1.setText(""); // Clear error message if input is valid
                }
            }
        });
        
        JButton btnNewButton = new JButton("ADD USER");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = textField.getText();
                String password = textField_1.getText();
                String fullname = textField_2.getText();
                String position = textField_3.getText();

                // Check if any of the text fields is empty
                if (username.isEmpty() || password.isEmpty() || fullname.isEmpty() || position.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields before adding a user.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    
                    try {
                        String checkSql = "SELECT * FROM logininfo WHERE username = ?";
                        PreparedStatement checkStatement = conn.prepareStatement(checkSql);
                        checkStatement.setString(1, username);
                        ResultSet resultSet = checkStatement.executeQuery();

                        if (resultSet.next()) {
                            JOptionPane.showMessageDialog(null, "Username already exists. Please choose a different username.", "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            
                            String insertSql = "INSERT INTO logininfo (username, password, fullname, position) VALUES (?, ?, ?, ?)";
                            PreparedStatement preparedStatement = conn.prepareStatement(insertSql);
                            preparedStatement.setString(1, username);
                            preparedStatement.setString(2, password);
                            preparedStatement.setString(3, fullname);
                            preparedStatement.setString(4, position);

                            int rowsAffected = preparedStatement.executeUpdate();
                            if (rowsAffected > 0) {
                                JOptionPane.showMessageDialog(null, "Registration Success!", "SUCCESS", JOptionPane.INFORMATION_MESSAGE);

                                textField.setText("");     
                                textField_1.setText("");   
                                textField_2.setText("");   
                                textField_3.setText("");   
                            } else {
                                System.out.println("Failed to add user to the database.");
                            }

                            // Close resources
                            preparedStatement.close();
                        }

                        resultSet.close();
                        checkStatement.close();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

       


        btnNewButton.setBounds(83, 253, 103, 23);
        contentPane.add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("Back");
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		ADMINPage frame = new ADMINPage();
				frame.setVisible(true);
				dispose();
        	}
        });
        btnNewButton_1.setBounds(-2, 0, 69, 23);
        contentPane.add(btnNewButton_1);
        
        JButton btnModifyUsers = new JButton("MODIFY USERS");
        btnModifyUsers.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		ModifUser frame = new ModifUser();
                frame.setVisible(true);
                dispose();
        		
        	}
        });
        btnModifyUsers.setBounds(310, 249, 135, 31);
        contentPane.add(btnModifyUsers);
        
      
        
    
        // Initialize the database connection
        initializeDatabaseConnection();
    }

    private void initializeDatabaseConnection() {
        String url = "jdbc:mysql://127.0.0.1:3306/javalogin";
        String user = "root"; 
        String password = ""; 

        try {
            conn = DriverManager.getConnection(url, user, password);
            if (conn != null) {
    
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
