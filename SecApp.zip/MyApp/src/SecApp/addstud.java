package SecApp;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

import pracapp.Login;
import javax.swing.JComboBox;
import com.toedter.calendar.JDateChooser;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;


public class addstud extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private DefaultTableModel tableModel;

    private Connection conn;
    private JLabel lblNewLabel_5;
    private JButton btnAdd;
    private JTable table = new JTable(tableModel);
    private JTextField textField_2;
    private JTextField textField_4;

    private JComboBox<String> comboBox;
    private JComboBox<String> comboBox_1;
    private JComboBox<String> comboBox_1_1;
    private JDateChooser dateChooser;


    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	addstud frame = new addstud();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    


    public class NumberDocument extends PlainDocument {
        @Override
        public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException {
            if (str == null) {
                return;
            }

            // Allow only numeric input
            if (str.matches("\\d+")) {
                super.insertString(offset, str, attr);
            }
        }
    }
    /**
     * Create the frame.
     */
    
    private void resetComboBoxes() {
        comboBox.setSelectedItem("SELECT");
        comboBox_1.setSelectedItem("SELECT");
        comboBox_1_1.setSelectedItem("SELECT");
    }
    public addstud() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        JButton btnNewButton_1 = new JButton("LOGOUT");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure you want to log out?", "Confirmation", JOptionPane.YES_NO_OPTION);

                if (dialogResult == JOptionPane.YES_OPTION) {
                    Login frame = new Login();
                    frame.setVisible(true);
                    dispose();
                }
            }
        });

        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Luther\\eclipse-workspace\\MyApp\\src\\SecApp\\icon.png"));
        setResizable(false);
        setBounds(100, 100, 920, 500);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblUser = new JLabel("STUDENT DETAILS INFORMATION");
        lblUser.setFont(new Font("Times New Roman", Font.BOLD, 24));
        lblUser.setBounds(282, 0, 446, 45);
        contentPane.add(lblUser);

        textField = new JTextField();
        textField.setEnabled(false);
        textField.setColumns(10);
        textField.setBounds(110, 77, 167, 20);
        contentPane.add(textField);

        JButton btnEnable = new JButton("ENABLE");
        btnEnable.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textField.setEnabled(true);
                textField_1.setEnabled(true);
                textField_2.setEnabled(true);
                textField_4.setEnabled(true);
            }
        });
        btnEnable.setBounds(714, 142, 89, 23);
        contentPane.add(btnEnable);
        
     
        
        Connection conn = null;
        comboBox = new JComboBox<String>();
        comboBox.setBounds(110, 175, 167, 22);
        contentPane.add(comboBox);

        try {
            String url = "jdbc:mysql://localhost:3306/sqlconnection";
            String user = "root";
            String password = "http://!MySQLD@tab4s3/#2024";
            conn = DriverManager.getConnection(url, user, password);

            Statement st = conn.createStatement();
            ResultSet r = st.executeQuery("SELECT CourseFullname FROM dbcr");

            // Add "SELECT" as the initial item in the JComboBox
            comboBox.addItem("SELECT");

            while (r.next()) {
                comboBox.addItem(r.getString("CourseFullname"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }


        JLabel lblNewLabel_2_1_1_1_1 = new JLabel("Year:");
        lblNewLabel_2_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2_1_1_1_1.setBounds(287, 180, 90, 14);
        contentPane.add(lblNewLabel_2_1_1_1_1);
        
  
        Connection connn = null;
        comboBox_1 = new JComboBox<String>();
        comboBox_1.setBounds(323, 175, 99, 22);
        contentPane.add(comboBox_1);

        try {
            String url = "jdbc:mysql://localhost:3306/sqlconnection";
            String user = "root";
            String password = "http://!MySQLD@tab4s3/#2024";
            connn = DriverManager.getConnection(url, user, password);

            Statement st = connn.createStatement();
            ResultSet r = st.executeQuery("SELECT Year FROM dbyrsem");

            // Add "SELECT" as the initial item in the JComboBox
            comboBox_1.addItem("SELECT");

            while (r.next()) {
                comboBox_1.addItem(r.getString("Year"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            if (connn != null) {
                try {
                    connn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
        
        JLabel lblNewLabel_2_1_1_1_1_1 = new JLabel("Sem:");
        lblNewLabel_2_1_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2_1_1_1_1_1.setBounds(432, 179, 90, 14);
        contentPane.add(lblNewLabel_2_1_1_1_1_1);
        
        
        Connection connnn = null;
        comboBox_1_1 = new JComboBox<String>();
        comboBox_1_1.setBounds(467, 176, 99, 22);
        contentPane.add(comboBox_1_1);

        try {
            String url = "jdbc:mysql://localhost:3306/sqlconnection";
            String user = "root";
            String password = "http://!MySQLD@tab4s3/#2024";
            connnn = DriverManager.getConnection(url, user, password);

            Statement st = connnn.createStatement();
            ResultSet r = st.executeQuery("SELECT Sem FROM dbyrsem");

            // Add "SELECT" as the initial item in the JComboBox
            comboBox_1_1.addItem("SELECT");

            while (r.next()) {
                comboBox_1_1.addItem(r.getString("Sem"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            if (connnn != null) {
                try {
                    connnn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }


        JLabel lblNewLabel_2 = new JLabel("Student Id:");
        lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2.setBounds(10, 79, 90, 14);
        contentPane.add(lblNewLabel_2);

        JLabel lblNewLabel_2_1 = new JLabel("Last Name:");
        lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2_1.setBounds(10, 117, 90, 14);
        contentPane.add(lblNewLabel_2_1);

        textField_1 = new JTextField();
        textField_1.setEnabled(false);
        textField_1.setColumns(10);
        textField_1.setBounds(110, 115, 167, 20);
        contentPane.add(textField_1);

        JLabel lblNewLabel_3 = new JLabel("Total records in the database: ");
        lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_3.setBounds(10, 415, 177, 14);
        contentPane.add(lblNewLabel_3);

        lblNewLabel_5 = new JLabel("0");
        lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_5.setBounds(191, 415, 703, 14);
        contentPane.add(lblNewLabel_5);

        // Update button
        JButton btnUpdate = new JButton("UPDATE");
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveChangesToDatabase();
            }
        });
        btnUpdate.setBounds(714, 176, 89, 23);
        contentPane.add(btnUpdate);
        
        
       
        dateChooser = new JDateChooser();
        dateChooser.setBounds(113, 145, 164, 20);
        contentPane.add(dateChooser);
        
        
       
        btnAdd = new JButton("ADD");
        btnAdd.setBounds(805, 142, 89, 23);
        contentPane.add(btnAdd);

        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Retrieve input values
                String st = textField.getText();
                String ln = textField_1.getText();
                String fn = textField_2.getText();
                String cn = textField_4.getText();
                
                // Retrieve the selected delivery date
                Date deliveryDate = dateChooser.getDate();
                if (deliveryDate == null) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields before adding an student.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Exit the method if the date is not selected
                }

                SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
                String dob = dateFormat.format(deliveryDate);

                // Retrieve selected items from JComboBox
                String cr = comboBox.getSelectedItem() != null ? comboBox.getSelectedItem().toString() : "";
                String yr = comboBox_1.getSelectedItem() != null ? comboBox_1.getSelectedItem().toString() : "";
                String sm = comboBox_1_1.getSelectedItem() != null ? comboBox_1_1.getSelectedItem().toString() : "";

                // Check if text fields are enabled and not empty
                boolean isTextFieldEnabled = textField.isEnabled() && !st.isEmpty();
                boolean isTextField1Enabled = textField_1.isEnabled() && !ln.isEmpty();
                boolean isTextField2Enabled = textField_2.isEnabled() && !fn.isEmpty();
                boolean isTextField4Enabled = textField_4.isEnabled() && !cn.isEmpty();

                // Check if JComboBoxes are not null
                boolean isComboBoxValid =
                    !cr.isEmpty() && !cr.equals("SELECT") &&
                    !yr.isEmpty() && !yr.equals("SELECT") &&
                    !sm.isEmpty() && !sm.equals("SELECT");

                if (!(isTextFieldEnabled && isTextField1Enabled && isTextField2Enabled && isTextField4Enabled && isComboBoxValid)) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields before adding a student.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Exit the method if any field is missing or disabled
                }

                Connection conn = null;
                try {
                    // Insert the data into the database
                    String url = "jdbc:mysql://localhost/sqlconnection";
                    String user = "root";
                    String password = "http://!MySQLD@tab4s3/#2024";
                    conn = DriverManager.getConnection(url, user, password);

                    String insertSql = "INSERT INTO regstud (StudentID, Lastname, Firstname, DofB, Course, Year, Sem, ContactNum ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement preparedStatement = conn.prepareStatement(insertSql);

                    preparedStatement.setString(1, st);
                    preparedStatement.setString(2, ln);
                    preparedStatement.setString(3, fn);
                    preparedStatement.setString(4, dob);
                    preparedStatement.setString(5, cr);
                    preparedStatement.setString(6, yr);
                    preparedStatement.setString(7, sm);
                    preparedStatement.setString(8, cn);

                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Added Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);

                        // Clear the text fields
                        textField.setText("");
                        textField_1.setText("");
                        textField_2.setText("");
                        textField_4.setText("");
                        textField_4.setDocument(new NumberDocument());

                        resetComboBoxes(); // Reset the combo boxes
                        dateChooser.setDate(null); // RESET DATECHOOSER

                        // Update the table
                        displayRegisteredItems();
                    }

                    preparedStatement.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                } finally {
                    if (conn != null) {
                        try {
                            conn.close();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        });

        // Initialize the database connection
        initializeDatabaseConnection();

        // Create and configure the table and table model
        initializeTable();

        displayRegisteredItems();
        }

   

    
    private void initializeDatabaseConnection() {
        try {
            // Open the connection
            String url = "jdbc:mysql://localhost/sqlconnection";
            String user = "root";
            String password = "http://!MySQLD@tab4s3/#2024";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    


    private void initializeTable() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 210, 884, 202);
        contentPane.add(scrollPane);

        table = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        scrollPane.setViewportView(table);

        tableModel = new DefaultTableModel();
        table.setModel(tableModel);
        tableModel.addColumn("Id");
        tableModel.addColumn("StudentID");
        tableModel.addColumn("Lastname");
        tableModel.addColumn("Firstname");
        tableModel.addColumn("Course");
        tableModel.addColumn("Date of Birth");   
        tableModel.addColumn("Year");
        tableModel.addColumn("Sem");
        tableModel.addColumn("Contact Number");

        rowSorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(rowSorter);

        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                adminpage frame = new adminpage();
                frame.setVisible(true);
                dispose();
            }
        });

        btnBack.setBounds(0, 0, 68, 20);
        contentPane.add(btnBack);

        // Delete button
        JButton btnDelete = new JButton("DELETE");
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String itemToDelete = (String) tableModel.getValueAt(selectedRow, 0);
                    deleteFromDatabase(itemToDelete);
                }
            }
        });
        btnDelete.setBounds(805, 176, 89, 23);
        contentPane.add(btnDelete);
        
        JLabel lblNewLabel_2_1 = new JLabel("First Name:");
        lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2_1.setBounds(287, 117, 90, 14);
        contentPane.add(lblNewLabel_2_1);
        
        textField_2 = new JTextField();
        textField_2.setEnabled(false);
        textField_2.setEnabled(false);
        textField_2.setColumns(10);
        textField_2.setBounds(387, 115, 167, 20);
        contentPane.add(textField_2);
        
        JLabel lblNewLabel_2_1_1 = new JLabel("Birtday:");
        lblNewLabel_2_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2_1_1.setBounds(10, 146, 90, 14);
        contentPane.add(lblNewLabel_2_1_1);
        
        JLabel lblNewLabel_2_1_1_1 = new JLabel("Course:");
        lblNewLabel_2_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2_1_1_1.setBounds(10, 185, 90, 14);
        contentPane.add(lblNewLabel_2_1_1_1);
        
       
        
        
        
        JLabel lblNewLabel_2_1_1_2 = new JLabel("Contact Number:");
        lblNewLabel_2_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2_1_1_2.setBounds(287, 146, 113, 14);
        contentPane.add(lblNewLabel_2_1_1_2);
        
        
		        
		
		textField_4 = new JTextField();
		textField_4.setEnabled(false);
		textField_4.setColumns(10);
		textField_4.setBounds(387, 143, 167, 20);
		contentPane.add(textField_4);
		
		
		textField_4.addKeyListener((KeyListener) new KeyAdapter() {
		    @Override
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if (!Character.isDigit(c) || textField_4.getText().length() >= 11) {
		            e.consume(); 
		        }
		    }
		});

		((AbstractDocument) textField_4.getDocument()).setDocumentFilter(new DocumentFilter() {
		    @Override
		    public void insertString(DocumentFilter.FilterBypass fb, int offset, String string, AttributeSet attr)
		            throws BadLocationException {
		        // Allow only numeric characters
		        if (string.matches("[0-9]+") && (fb.getDocument().getLength() + string.length()) <= 11) {
		            super.insertString(fb, offset, string, attr);
		        }
		    }
		
		    @Override
		    public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
		            throws BadLocationException {
		        // Allow only numeric characters
		        if (text.matches("[0-9]+") && (fb.getDocument().getLength() + text.length() - length) <= 11) {
		            super.replace(fb, offset, length, text, attrs);
		        }
		    }
		});
		        
		   
        

        ListSelectionModel selectionModel = table.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
            	  if (!e.getValueIsAdjusting()) {
                      int selectedRow = table.getSelectedRow();

                      if (selectedRow != -1) {
                          // Retrieve the StudentID from the selected row
                          String studentID = (String) tableModel.getValueAt(selectedRow, 0);

                          Connection conn = null;
                          try {
                              // Replace these with your actual database details
                              String url = "jdbc:mysql://localhost:3306/sqlconnection";
                              String user = "root";
                              String password = "http://!MySQLD@tab4s3/#2024";

                              conn = DriverManager.getConnection(url, user, password);

                              // Execute a SQL query to fetch the birthday and contact number based on the selected StudentID
                              String query = "SELECT DofB, ContactNum FROM regstud WHERE Id = ?";
                              PreparedStatement preparedStatement = conn.prepareStatement(query);
                              preparedStatement.setString(1, studentID);
                              ResultSet resultSet = preparedStatement.executeQuery();

                              if (resultSet.next()) {
                                  String dobFromDatabase = resultSet.getString("DofB");
                                  String contactNumFromDatabase = resultSet.getString("ContactNum");
                                  
                                  // Display the birthday
                                  SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM d, yyyy");
                                  try {
                                      Date birthday = dateFormat.parse(dobFromDatabase);
                                      if (birthday != null) {
                                          dateChooser.setDate(birthday);
                                      }
                                  } catch (ParseException ex) {
                                      ex.printStackTrace();
                                  }

                                  // Display the contact number
                                  textField_4.setText(contactNumFromDatabase);
                              }

                          } catch (SQLException ex) {
                              ex.printStackTrace();
                          } finally {
                              try {
                                  if (conn != null) {
                                      conn.close();
                                  }
                              } catch (SQLException ex) {
                                  ex.printStackTrace();
                              }
                          }

                          String sn = (String) tableModel.getValueAt(selectedRow, 1);
                          String ln = (String) tableModel.getValueAt(selectedRow, 2);
                          String fn = (String) tableModel.getValueAt(selectedRow, 3);

                          textField.setText(sn);
                          textField_1.setText(ln);
                          textField_2.setText(fn);
                    }
                }
            }
        });
    }
    
    private void displayRegisteredItems() {
        try {
            String sql = "SELECT Id, StudentID, Lastname, Firstname, DofB, Course, Year, Sem, ContactNum FROM regstud";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            tableModel.setRowCount(0);
            int studentCount = 0;

            while (resultSet.next()) {
            	String id = resultSet.getString("Id");
                String st = resultSet.getString("StudentID");
                String ln = resultSet.getString("Lastname");
                String fn = resultSet.getString("Firstname");
                String dob = resultSet.getString("DofB");
                String cr = resultSet.getString("Course");       
                String yr = resultSet.getString("Year");
                String sm = resultSet.getString("Sem");
                String cn = resultSet.getString("ContactNum");

                tableModel.addRow(new Object[] { id, st, ln, fn, cr, dob, yr, sm, cn });
                studentCount++;
            }

            lblNewLabel_5.setText(Integer.toString(studentCount));

            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void saveChangesToDatabase() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String newst = textField.getText();
            String newln = textField_1.getText();
            String newfn = textField_2.getText();
            String newcn = textField_4.getText();

            // Retrieve the selected delivery date
            Date deliveryDate = dateChooser.getDate();
            if (deliveryDate != null) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM d, yyyy", Locale.ENGLISH);
                String newdob = dateFormat.format(deliveryDate);

                // Check if text fields are empty
                if (!textField.isEnabled() || newst.isEmpty() || !textField_1.isEnabled() || newln.isEmpty() || 
                        !textField_2.isEnabled() || newfn.isEmpty() || !textField_4.isEnabled() || newcn.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please fill in all fields before saving changes.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                    Object selectedCourse = comboBox.getSelectedItem();
                    Object selectedYear = comboBox_1.getSelectedItem();
                    Object selectedSemester = comboBox_1_1.getSelectedItem();

                    if (selectedCourse != null && selectedYear != null && selectedSemester != null
                            && !selectedCourse.toString().equals("SELECT")
                            && !selectedYear.toString().equals("SELECT")
                            && !selectedSemester.toString().equals("SELECT")) {
                        String cr = selectedCourse.toString();
                        String yr = selectedYear.toString();
                        String sm = selectedSemester.toString();

                        String itemToUpdate = (String) tableModel.getValueAt(selectedRow, 0);

                        int confirmation = JOptionPane.showConfirmDialog(null, "Are you sure you want to update this record?", "Confirmation", JOptionPane.YES_NO_OPTION);
                        if (confirmation == JOptionPane.YES_OPTION) {
                            try {
                                String updateSql = "UPDATE regstud SET StudentID = ?, Lastname = ?, Firstname = ?, DofB = ?, Course = ?, Year = ?, Sem = ?, ContactNum = ? WHERE Id = ?";
                                PreparedStatement updateStatement = conn.prepareStatement(updateSql);
                                updateStatement.setString(1, newst);
                                updateStatement.setString(2, newln);
                                updateStatement.setString(3, newfn);
                                updateStatement.setString(4, newdob);
                                updateStatement.setString(5, cr);
                                updateStatement.setString(6, yr);
                                updateStatement.setString(7, sm);
                                updateStatement.setString(8, newcn);
                                updateStatement.setString(9, itemToUpdate);

                             

                                int updatedRows = updateStatement.executeUpdate();

                                if (updatedRows > 0) {
                                    JOptionPane.showMessageDialog(null, "Changes saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                                    tableModel.setValueAt(newst, selectedRow, 1); // Assuming index 1 is the column to update
                                    tableModel.setValueAt(newln, selectedRow, 2); // Index 2 for the last name
                                    tableModel.setValueAt(newfn, selectedRow, 3); // Index 3 for the first name

                                    textField.setText("");
                                    textField_1.setText("");
                                    textField_2.setText("");
                                    textField_4.setText("");
                                    textField_4.setDocument(new NumberDocument());

                                    resetComboBoxes(); // Reset the combo boxes
                                    dateChooser.setDate(null); // RESET DATECHOOSER
                                } else {
                                    JOptionPane.showMessageDialog(null, "Failed to save changes to the database.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            } catch (SQLException ex) {
                                ex.printStackTrace();
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Please select a valid course, year, and semester before saving changes.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select a valid date.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    private void deleteFromDatabase(String courseCode) {
    	
    	 int confirmationn = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this record?", "Confirmation", JOptionPane.YES_NO_OPTION);
         if (confirmationn == JOptionPane.YES_OPTION) {
        try {
            String deleteSql = "DELETE FROM regstud WHERE Id = ?";
            PreparedStatement deleteStatement = conn.prepareStatement(deleteSql);
            deleteStatement.setString(1, courseCode);

            int deletedRows = deleteStatement.executeUpdate();

            if (deletedRows > 0) {
                // Successful deletion
                JOptionPane.showMessageDialog(null, "Row deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Remove the row from the JTable
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    tableModel.removeRow(selectedRow);
                }
                // Update the total record count label
                lblNewLabel_5.setText(String.valueOf(tableModel.getRowCount()));
                textField.setText("");
                textField_1.setText("");
                textField_2.setText("");
                textField_4.setText("");
                textField_4.setDocument(new NumberDocument());
                
                resetComboBoxes(); // Reset the combo boxes
                dateChooser.setDate(null); // RESET DATECHOOSER
                
            } else {
                // Handle deletion failure
                JOptionPane.showMessageDialog(null, "Failed to delete the row.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            deleteStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
}
