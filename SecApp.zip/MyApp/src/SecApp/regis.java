package SecApp;

import java.awt.Component;
import java.awt.EventQueue;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pracapp.ADMINPage;
import pracapp.ModifUser;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class regis extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private Connection conn;
	private Component btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					regis frame = new regis();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	
	    	
	public regis() {
		
    	addWindowListener(new WindowAdapter() {
    	    @Override
    	    public void windowClosing(WindowEvent e) {
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Proceed to admin page?", "Confirmation", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.YES_OPTION) {
    	            // Create and show the "about" frame
    	            adminpage aboutFrame = new adminpage();
    	            aboutFrame.setVisible(true);

    	     
    	            dispose(); // Close the current frame
    	        } else {
    	            // If "No" is selected, open the "adminpage" frame
    	            regis adminFrame = new regis();
    	            adminFrame.setVisible(true);
    	            dispose(); // Close the current frame
    	        }
    	    }
    	});

					
		setResizable(false);
		setBounds(100, 100, 600, 400);
		 setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegister = new JLabel("ADMIN / USER REGISTRATION");
		lblRegister.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblRegister.setBounds(128, 0, 361, 45);
		contentPane.add(lblRegister);
		
		JLabel lblNewLabel_1 = new JLabel("USERNAME:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(49, 103, 82, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("PASSWORD:");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(49, 164, 82, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("POSITION:");
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_1_2.setBounds(49, 220, 82, 14);
		contentPane.add(lblNewLabel_1_2);
		
		JFormattedTextField user = new JFormattedTextField();
		user.setBounds(141, 97, 233, 26);
		contentPane.add(user);
		
		JFormattedTextField pass = new JFormattedTextField();
		pass.setBounds(141, 158, 233, 26);
		contentPane.add(pass);
		
		JFormattedTextField pos = new JFormattedTextField();
		pos.setBounds(141, 214, 96, 26);
		contentPane.add(pos);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel.setBounds(141, 239, 107, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("FULLNAME:");
		lblNewLabel_1_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_1_2_1.setBounds(49, 285, 82, 14);
		contentPane.add(lblNewLabel_1_2_1);
		
		JFormattedTextField fn = new JFormattedTextField();
		fn.setBounds(141, 273, 233, 26);
		contentPane.add(fn);
		
		
		pos.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                String currentText = pos.getText();
                
                if (currentText.length() >= 1 || (!((c >= '0' && c <= '1') || c == '\b')) ) {
                    e.consume(); // Prevent the character from being entered
                
                    lblNewLabel.setText("1=ADMIN and 0=USER"); // Set error message
                } else {
                	lblNewLabel.setText(""); // Clear error message if input is valid
                }
            }
        });
        
		
		JButton btnNewButton_1 = new JButton("Register");
		btnNewButton_1.setBounds(193, 324, 107, 26);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			                String username = user.getText();
			                String password = pass.getText();
			                String fullname = fn.getText();
			                String position = pos.getText();

			                // Check if any of the text fields is empty
			                if (username.isEmpty() || password.isEmpty() || fullname.isEmpty() || position.isEmpty()) {
			                    JOptionPane.showMessageDialog(null, "Please fill in all fields before adding a user.", "Error", JOptionPane.ERROR_MESSAGE);
			                } else {
			                    
			                    try {
			                        String checkSql = "SELECT * FROM secapplogin WHERE username = ?";
			                        PreparedStatement checkStatement = conn.prepareStatement(checkSql);
			                        checkStatement.setString(1, username);
			                        ResultSet resultSet = checkStatement.executeQuery();

			                        if (resultSet.next()) {
			                            JOptionPane.showMessageDialog(null, "Username already exists. Please choose a different username.", "Error", JOptionPane.ERROR_MESSAGE);
			                        } else {
			                            
			                            String insertSql = "INSERT INTO secapplogin (username, password, position, fullname) VALUES (?, ?, ?, ?)";
			                            PreparedStatement preparedStatement = conn.prepareStatement(insertSql);
			                            preparedStatement.setString(1, username);
			                            preparedStatement.setString(2, password);
			                            preparedStatement.setString(3, position);
			                            preparedStatement.setString(4, fullname);
			                            

			                            int rowsAffected = preparedStatement.executeUpdate();
			                            if (rowsAffected > 0) {
			                                JOptionPane.showMessageDialog(null, "Registration Success!", "SUCCESS", JOptionPane.INFORMATION_MESSAGE);

			                                user.setText("");     
			                                pass.setText("");   
			                                pos.setText("");   
			                                fn.setText("");   
			                            } else {
			                                System.out.println("Failed to add user to the database.");
			                            }

			                            // Close resources
			                            preparedStatement.close();
			                        }
			                        resultSet.close();
			                        checkStatement.close();
			                    } catch (Exception ex) {
			                        ex.printStackTrace();
			                    
			                    }
			                }
			            }
			        });

			       
	
	            
	        
	        JButton btnModifyUsers = new JButton("MODIFY USERS");
	        btnModifyUsers.setBounds(2, 50, 69, 23);
	        contentPane.add(btnModifyUsers);
	        btnModifyUsers.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		regmodif frame = new regmodif();
                    frame.setVisible(true);
	                dispose();
	        		
	        	}
	        });
	        btnModifyUsers.setBounds(449, 330, 135, 31);
	        contentPane.add(btnModifyUsers);
	        
	      
	        
	    
	        // Initialize the database connection
	        initializeDatabaseConnection();
	    }

	    private void initializeDatabaseConnection() {
	        String url = "jdbc:mysql://localhost:3306/sqlconnection";
	        String user = "root"; 
	        String password = "http://!MySQLD@tab4s3/#2024"; 

	        try {
	            conn = DriverManager.getConnection(url, user, password);
	            if (conn != null) {
	    
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}
