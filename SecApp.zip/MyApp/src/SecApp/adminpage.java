package SecApp;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import pracapp.Login;

import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class adminpage extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField txtSearch;
    private JPanel contentPane;
    private JLabel lblNewLabel_5;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private DefaultTableModel tableModel;
    private JTable table;
    private Connection conn;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    adminpage frame = new adminpage();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public adminpage() {
    	addWindowListener(new WindowAdapter() {
    	    @Override
    	    public void windowClosing(WindowEvent e) {
    	        int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Confirmation", JOptionPane.YES_NO_OPTION);

    	        if (dialogResult == JOptionPane.NO_OPTION) {
    	            // Create and show the "about" frame
    	            adminpage frame = new adminpage();
                    frame.setVisible(true);
    	            
    	        }
    	        else if (dialogResult == JOptionPane.YES_OPTION) {
    	            // Create and show the "about" frame
    	            about aboutFrame = new about();
    	            aboutFrame.setVisible(true);
    	            dispose(); // Close the current frame
    	        }
    	    }
    	});




        // Set up the main frame
        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Luther\\eclipse-workspace\\MyApp\\src\\SecApp\\icon.png"));
        setResizable(false);
       
        setBounds(100, 100, 920, 500);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Create and configure components
        JLabel lblAdministrator = new JLabel("EMPLOYEE INFORMATION RECORD");
        lblAdministrator.setFont(new Font("Times New Roman", Font.BOLD, 24));
        lblAdministrator.setBounds(283, 0, 430, 45);
        contentPane.add(lblAdministrator);

        JLabel lblNewLabel_3 = new JLabel("Total records in the database: ");
        lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_3.setBounds(10, 384, 177, 14);
        contentPane.add(lblNewLabel_3);

        lblNewLabel_5 = new JLabel("0");
        lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_5.setBounds(188, 384, 703, 14);
        contentPane.add(lblNewLabel_5);

        txtSearch = new JTextField();
        txtSearch.setBounds(73, 82, 221, 20);
        contentPane.add(txtSearch);
        txtSearch.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Search");
        lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2.setBounds(10, 84, 46, 14);
        contentPane.add(lblNewLabel_2);
        
        JButton btnNewButton = new JButton("File");
        btnNewButton.setBounds(0, 0, 59, 20);
        contentPane.add(btnNewButton);

        JPopupMenu popupMenu = new JPopupMenu();

        // Corrected import for JMenuItem
        javax.swing.JMenuItem menuItem1 = new JMenuItem("Course");
        javax.swing.JMenuItem menuItem2 = new JMenuItem("Year and Semester");
        javax.swing.JMenuItem menuItem3 = new JMenuItem("Student");
        javax.swing.JMenuItem menuItem4 = new JMenuItem("Registration");

        menuItem1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Open selected.");
                
                userpage frame = new userpage();
				frame.setVisible(true);
				dispose();
            }
        });

        menuItem2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	JOptionPane.showMessageDialog(null, "Open selected.");
            	
            	yearandseminfosys frame = new yearandseminfosys();
                frame.setVisible(true);
                dispose();
            }
        });
        menuItem3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	JOptionPane.showMessageDialog(null, "Open selected.");
            	addstud frame = new addstud();
                frame.setVisible(true);
                dispose();
            }
        });
        menuItem4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	JOptionPane.showMessageDialog(null, "Open selected.");
            	regis frame = new regis();
                frame.setVisible(true);
                dispose();
            }
        });


 

        popupMenu.add(menuItem1);
        popupMenu.add(menuItem2);
        popupMenu.add(menuItem3);
        popupMenu.add(menuItem4);
       // popupMenu.addSeparator();
  

        btnNewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show the popup menu below the button
                popupMenu.show(btnNewButton, 0, btnNewButton.getHeight());
            }
        }); 
   

        // Initialize the database connection
        initializeDatabaseConnection();

        // Create and configure the table and table model
        initializeTable();
        
        

        // Add a DocumentListener to the search bar's document
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                filterItems();
            }

            public void removeUpdate(DocumentEvent e) {
                filterItems();
            }

            public void changedUpdate(DocumentEvent e) {
                filterItems();
            }
            
      

            private void filterItems() {
                String text = txtSearch.getText();
                if (text.trim().isEmpty()) {
                    // If the search text is empty, show all rows
                    rowSorter.setRowFilter(null);
                   
                } else {
                    // Use a RowFilter to show only rows that match the search text
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
            
            
        });
    }

    private void initializeDatabaseConnection() {
        // Establish a database connection
        try {
            String url = "jdbc:mysql://localhost:3306/sqlconnection";
            String user = "root";
            String password = "http://!MySQLD@tab4s3/#2024";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void initializeTable() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 106, 884, 277);
        contentPane.add(scrollPane);

       
        //disable to edit table
        table = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        scrollPane.setViewportView(table);

        // Create the JTable and set the table model
        tableModel = new DefaultTableModel();
        table.setModel(tableModel); // Set the table model to the existing table
        //disable to edit table

        // Initialize the table model columns
        tableModel.addColumn("School Id");
        tableModel.addColumn("Fullname");
        tableModel.addColumn("Course");
        tableModel.addColumn("Year");
        tableModel.addColumn("Semester");

        // Create a TableRowSorter for the tableModel
        rowSorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(rowSorter);
        
  
        displayRegisteredItems();
    }

    private void displayRegisteredItems() {
        try {
            String sql = "SELECT StudentID, Lastname, Firstname, DofB, Course, Year, Sem, ContactNum FROM regstud";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            tableModel.setRowCount(0);
            int studentCount = 0;

            while (resultSet.next()) {
                String st = resultSet.getString("StudentID");
                String ln = resultSet.getString("Lastname");
                String fn = resultSet.getString("Firstname");
                String wn = ln + ", " + fn;
                String dob = resultSet.getString("DofB");
                String cr = resultSet.getString("Course");
                String yr = resultSet.getString("Year");
                String sm = resultSet.getString("Sem");
                String cn = resultSet.getString("ContactNum");

                // Add the row to the table model
                tableModel.addRow(new Object[]{st, wn, cr, yr, sm});
                studentCount++;
            }

            // Update the total student count label
            lblNewLabel_5.setText(Integer.toString(studentCount));

            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
