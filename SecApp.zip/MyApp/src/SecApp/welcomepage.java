package SecApp;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import java.awt.Toolkit;

public class welcomepage extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private int loadingProgress = 0;
    private Timer loadingTimer;
    private int loadingBarWidth = 0; // Width of the loading bar
    private Color yellowGreen = new Color(154, 205, 50);
    private int timerDelay = 60;

    public welcomepage() {
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Luther\\eclipse-workspace\\MyApp\\src\\SecApp\\icon.png"));
    	setUndecorated(true); // Hide title bar, exit button, minimize button, maximize button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        setLocationRelativeTo(null);
        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                int width = getWidth();
                int height = getHeight();

                // Draw the loading bar background
                g.setColor(Color.LIGHT_GRAY);
                g.fillRect(0, height - 20, width, 20);

                // Draw the loading bar
                g.setColor(yellowGreen);
                g.fillRect(0, height - 20, loadingBarWidth, 20);

                // Draw the loading percentage text
                String percentageText = loadingProgress + "%";
                Font textFont = new Font("Times New Roman", Font.BOLD, 12);
                g.setColor(Color.BLACK);
                g.setFont(textFont);
                int textWidth = g.getFontMetrics().stringWidth(percentageText);
                int textX = (width - textWidth) / 2;
                int textY = height - 20 + 15;
                g.drawString(percentageText, textX, textY);
            }
        };
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblWelcome = new JLabel("UNIVERSIDAD DE MANILA");
        lblWelcome.setFont(new Font("Times New Roman", Font.BOLD, 24));
        lblWelcome.setBounds(148, 11, 324, 45);
        contentPane.add(lblWelcome);

        // Create a background image label
        ImageIcon backgroundImageIcon = new ImageIcon("C:\\Users\\Luther\\eclipse-workspace\\MyApp\\src\\SecApp/icon.png"); // Replace with your image path
        Image backgroundImage = backgroundImageIcon.getImage();
        backgroundImage = backgroundImage.getScaledInstance(200, 200, Image.SCALE_SMOOTH); // Adjust the dimensions

        ImageIcon scaledBackgroundImageIcon = new ImageIcon(backgroundImage);
        
        JLabel lblUniversityManagementSystem = new JLabel("UNIVERSITY MANAGEMENT SYSTEM");
        lblUniversityManagementSystem.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblUniversityManagementSystem.setBounds(158, 50, 324, 45);
        contentPane.add(lblUniversityManagementSystem);
        JLabel backgroundLabel = new JLabel(scaledBackgroundImageIcon);
        backgroundLabel.setBounds(0, 0, 600, 400); // Adjust the location and size
        getContentPane().add(backgroundLabel);

        loadingTimer = new Timer(timerDelay, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Update the loading progress and loading bar width
                loadingProgress += 1;
                loadingBarWidth = (loadingProgress * getWidth()) / 100;
                contentPane.repaint();

                // Adjust the timer speed when it reaches 60%
                if (loadingProgress == 20) {
                    timerDelay = 200; // Slower timer speed
                    loadingTimer.setDelay(timerDelay);
                
                } else if (loadingProgress >= 50) {
                    timerDelay = 50; // Slower timer speed
                    loadingTimer.setDelay(timerDelay);
                }
                else if (loadingProgress >= 80) {
                    timerDelay = 25; // Return to the original timer speed
                    loadingTimer.setDelay(timerDelay);
                }

                if (loadingProgress >= 100) {
                    loadingTimer.stop(); // Stop the loading timer
                    proceedToLogin();
                }
            }
        });

        // Start the loading timer
        loadingTimer.start();
    }

    // Method to proceed to the login page
    private void proceedToLogin() {
        // Close the current welcome page
    	dispose();
        // Create and open the login page
        Index loginFrame = new Index();
        loginFrame.setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                welcomepage frame = new welcomepage();
                frame.setVisible(true);
            }
        });
    }
}
