package SecApp;

import java.awt.EventQueue;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class about extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    about frame = new about();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    
    
    public about() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Directly create and show the "login" frame when the "about" frame is closed
                Index loginFrame = new Index();
                loginFrame.setVisible(true);
                dispose(); // Close the current frame
               
            }
        });
    

        
    	setResizable(false);
        // Initialize the JFrame and content pane
        setTitle("About Us");

        setSize(663, 502);
        setLocationRelativeTo(null);
        Container contentPane = getContentPane();
        contentPane.setBackground(new Color(200, 255, 100)); // Lighter yellow-green color

        contentPane.setLayout(null);
        // Create a JTextPane with transparent background
 
     // Create a JTextPane with centered text
        JTextPane txtpnCreatedInJava1 = new JTextPane();
        txtpnCreatedInJava1.setContentType("text/html"); // Set content type to HTML
        txtpnCreatedInJava1.setText("<html><div align='center'>Created in Java Eclipse with MySQL Workbench for Database.<br>Created By: Jeron Luther E.S. Castro<br>Created Date: October 21, 2023<br>Copyright © 2023</div></html>");
        txtpnCreatedInJava1.setBounds(75, 362, 510, 90);
        txtpnCreatedInJava1.setOpaque(false); // Make it transparent
        txtpnCreatedInJava1.setForeground(Color.BLACK); // Set text color to black
        txtpnCreatedInJava1.setEditable(false); // Make it uneditable
        txtpnCreatedInJava1.setFocusable(false); // Make it unselectable

      
        contentPane.add(txtpnCreatedInJava1);

        // Create a JLabel
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(234, 11, 220, 216);
        contentPane.add(lblNewLabel);

        // Load the image
        try {
            BufferedImage originalImage = ImageIO.read(new File("C:\\Users\\Luther\\eclipse-workspace\\MyApp\\src\\SecApp\\icon.png"));

            // Create a resized image with higher quality
            int newWidth = lblNewLabel.getWidth();
            int newHeight = lblNewLabel.getHeight();
            BufferedImage resizedImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = resizedImage.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
            g.dispose();

            // Set the resized image as the icon for the JLabel
            lblNewLabel.setIcon(new ImageIcon(resizedImage));
            
            JLabel lblNewLabel_2 = new JLabel("UNIVERSIDAD DE MANILA");
            lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 22));
            lblNewLabel_2.setBounds(196, 295, 296, 29);
            getContentPane().add(lblNewLabel_2);
                        
                        JLabel lblNewLabel_2_1 = new JLabel("STUDENT MANAGEMENT SYSTEM");
                        lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.ITALIC, 14));
                        lblNewLabel_2_1.setBounds(234, 322, 220, 29);
                        getContentPane().add(lblNewLabel_2_1);
                                                
                                                JLabel lblNewLabel_1 = new JLabel("");
                                                lblNewLabel_1.setBorder(null); // Add a 1-pixel red border
                                                
                                                            lblNewLabel_1.setBounds(63, 278, 533, 149);
                                                            getContentPane().add(lblNewLabel_1);
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
