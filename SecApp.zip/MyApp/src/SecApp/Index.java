package SecApp;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;





public class Index extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField passwordField;
	private JFormattedTextField formattedTextField;
	private Connection conn;

	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Index frame = new Index();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	//insert entries in sql 
	//INSERT INTO table_name (column1, column2, column3, ...)
	//VALUES (value1, value2, value3, ...);

	public Index() {
		
		contentPane = new JPanel() {
		    @Override
		    protected void paintComponent(Graphics g) {
		        super.paintComponent(g);
		        
		        // Create a gradient with a sharper transition
		        GradientPaint gradient = new GradientPaint(0, 0, new Color(200, 250, 100), getWidth(), getHeight(), new Color(150, 220, 70));
		        Graphics2D g2d = (Graphics2D) g;
		        g2d.setPaint(gradient);
		        g2d.fillRect(0, 0, getWidth(), getHeight());
		    }
		};

		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Luther\\eclipse-workspace\\MyApp\\src\\SecApp\\icon.png"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);       
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel.setBounds(269, 40, 96, 45);
		contentPane.add(lblNewLabel);
		
	
		formattedTextField = new JFormattedTextField();
		formattedTextField.setBounds(147, 146, 315, 26);
		contentPane.add(formattedTextField);
		
		JLabel lblNewLabel_1 = new JLabel("USERNAME:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(55, 152, 82, 14);
		contentPane.add(lblNewLabel_1);
		

		passwordField = new JPasswordField();
		passwordField.setBounds(147, 208, 315, 26);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel_1_1 = new JLabel("PASSWORD:");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(55, 214, 82, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Show Password");
		chckbxNewCheckBox.addItemListener(new ItemListener() {
		    public void itemStateChanged(ItemEvent e) {
		        if (e.getStateChange() == ItemEvent.SELECTED) {
		            // Show the password
		            passwordField.setEchoChar((char) 0); // Display the password as plain text
		        } else {
		            // Hide the password
		            passwordField.setEchoChar('\u2022'); // Display the password as dots (password style)
		        }
		    }
		});
		chckbxNewCheckBox.setBackground(new Color(192, 192, 192));
		chckbxNewCheckBox.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		chckbxNewCheckBox.setBounds(365, 234, 97, 23);
		contentPane.add(chckbxNewCheckBox);

		
		JButton btnNewButton = new JButton("Enter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginRequest();				
			}
		});
		btnNewButton.setBackground(new Color(64, 128, 128));
		btnNewButton.setBounds(242, 287, 96, 33);
		contentPane.add(btnNewButton);
		
		
		}
	
	private void loginRequest() {
	    String un = formattedTextField.getText();
	    char[] passwordChars = passwordField.getPassword();
	    String pw = new String(passwordChars);

	    // Ensure that your database connection is set up correctly
	    conn = initializeDatabaseConnection(); // Assign to the class field "conn"

	    if (conn == null) {
	        // Handle the case where the database connection is not established
	        JOptionPane.showMessageDialog(null, "Database connection error", "Error", JOptionPane.ERROR_MESSAGE);
	        return; // Exit the method
	    }

	    try {
	        String sql = "SELECT * FROM secapplogin WHERE username = ? AND password = ?";
	        PreparedStatement preparedStatement = conn.prepareStatement(sql);
	        preparedStatement.setString(1, un);
	        preparedStatement.setString(2, pw);
	        ResultSet resultSet = preparedStatement.executeQuery();

	        if (resultSet.next()) {
	            int userPosition = resultSet.getInt("position");

	            if (userPosition == 1) {
	                // Admin login successful
	                JOptionPane.showMessageDialog(null, "Admin Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);

	                // Open the admin page 
	                adminpage frame = new adminpage();
					frame.setVisible(true);
	                dispose();
	            } else {
	                // Regular user login successful
	                JOptionPane.showMessageDialog(null, "User Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);

	                // Open the user page
	                addstuduser frame = new addstuduser();
                    frame.setVisible(true);
                    
                    
                    
	                dispose();
	            }
	        } else {
	            // Invalid username or password
	            JOptionPane.showMessageDialog(null, "Login Failed. Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
	            // Clear the input fields
	            formattedTextField.setText("");
	            passwordField.setText("");
	        }

	        // Close resources
	        resultSet.close();
	        preparedStatement.close();

	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    } finally {
	        try {
	            conn.close(); // Close the database connection in a finally block
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}

	private Connection initializeDatabaseConnection() {
	    String url = "jdbc:mysql://localhost:3306/sqlconnection";
	    String user = "root";
	    String password = "http://!MySQLD@tab4s3/#2024";

	    Connection conn = null;

	    try {
	        conn = DriverManager.getConnection(url, user, password);
	        if (conn != null) {
	            System.out.println("Connected to the database!");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return conn;
	}	
}
