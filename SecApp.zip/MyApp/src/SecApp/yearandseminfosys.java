package SecApp;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import pracapp.Login;

public class yearandseminfosys extends JFrame {
	


    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private DefaultTableModel tableModel;

    private Connection conn;
    private JLabel lblNewLabel_5;
    private JButton btnAdd;
    private JTable table = new JTable(tableModel);

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	yearandseminfosys frame = new yearandseminfosys();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public yearandseminfosys() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        JButton btnNewButton_1 = new JButton("LOGOUT");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure you want to log out?", "Confirmation", JOptionPane.YES_NO_OPTION);

                if (dialogResult == JOptionPane.YES_OPTION) {
                    Login frame = new Login();
                    frame.setVisible(true);
                    dispose();
                }
            }
        });

        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Luther\\eclipse-workspace\\MyApp\\src\\SecApp\\icon.png"));
        setResizable(false);
        setBounds(100, 100, 920, 500);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblUser = new JLabel("YEAR AND SEMESTER INFORMATION");
        lblUser.setFont(new Font("Times New Roman", Font.BOLD, 24));
        lblUser.setBounds(269, 0, 459, 45);
        contentPane.add(lblUser);

        textField = new JTextField();
        textField.setEnabled(false);
        textField.setColumns(10);
        textField.setBounds(110, 106, 260, 20);
        contentPane.add(textField);

        JButton btnEnable = new JButton("ENABLE");
        btnEnable.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                textField.setEnabled(true);
                textField_1.setEnabled(true);
            }
        });
        btnEnable.setBounds(410, 157, 89, 23);
        contentPane.add(btnEnable);

        JLabel lblNewLabel_2 = new JLabel("Year:");
        lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2.setBounds(10, 108, 90, 14);
        contentPane.add(lblNewLabel_2);

        JLabel lblNewLabel_2_1 = new JLabel("Semester:");
        lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_2_1.setBounds(10, 160, 90, 14);
        contentPane.add(lblNewLabel_2_1);

        textField_1 = new JTextField();
        textField_1.setEnabled(false);
        textField_1.setColumns(10);
        textField_1.setBounds(110, 158, 260, 20);
        contentPane.add(textField_1);

        JLabel lblNewLabel_3 = new JLabel("Total records in the database: ");
        lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_3.setBounds(10, 415, 177, 14);
        contentPane.add(lblNewLabel_3);

        lblNewLabel_5 = new JLabel("0");
        lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lblNewLabel_5.setBounds(191, 415, 703, 14);
        contentPane.add(lblNewLabel_5);

        // Update button
        JButton btnUpdate = new JButton("UPDATE");
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveChangesToDatabase();
            }
        });
        btnUpdate.setBounds(599, 157, 89, 23);
        contentPane.add(btnUpdate);
        
        
        btnAdd = new JButton("ADD");
        btnAdd.setBounds(504, 157, 89, 23);
        contentPane.add(btnAdd);
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String crc = textField.getText();
                String cfn = textField_1.getText();
                boolean isTextFieldEnabled = textField.isEnabled();
                boolean isTextField1Enabled = textField_1.isEnabled();

                if (!isTextFieldEnabled || !isTextField1Enabled) {
                    JOptionPane.showMessageDialog(null, "Please enable the fields before adding an item.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (textField.getText().isEmpty() || textField_1.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields before adding an item.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Check if the course code already exists in the database
         
                        try {
                            // Insert the data into the database
                            String url = "jdbc:mysql://localhost/sqlconnection";
                            String user = "root";
                            String password = "http://!MySQLD@tab4s3/#2024"; // Replace with your actual password
                            conn = DriverManager.getConnection(url, user, password);

                            String insertSql = "INSERT INTO dbyrsem (Year, Sem) VALUES (?, ?)";
                            PreparedStatement preparedStatement = conn.prepareStatement(insertSql);
                            preparedStatement.setString(1, crc);
                            preparedStatement.setString(2, cfn);

                            int rowsAffected = preparedStatement.executeUpdate();

                            if (rowsAffected > 0) {
                                JOptionPane.showMessageDialog(null, "Added Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);

                                // Update the table
                                displayRegisteredItems();

                                // Clear the text fields
                                textField.setText("");
                                textField_1.setText("");
                            }


                            preparedStatement.close();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            
        });

        // Initialize the database connection
        initializeDatabaseConnection();

        // Create and configure the table and table model
        initializeTable();

        displayRegisteredItems();
    }

    private void initializeDatabaseConnection() {
        try {
            // Open the connection
            String url = "jdbc:mysql://localhost/sqlconnection";
            String user = "root";
            String password = "http://!MySQLD@tab4s3/#2024";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void initializeTable() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 210, 884, 202);
        contentPane.add(scrollPane);

        table = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        scrollPane.setViewportView(table);

        tableModel = new DefaultTableModel();
        table.setModel(tableModel);

        tableModel.addColumn("Id");
        tableModel.addColumn("Year");
        tableModel.addColumn("Semester");

        rowSorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(rowSorter);

        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                adminpage frame = new adminpage();
                frame.setVisible(true);
                dispose();
            }
        });

        btnBack.setBounds(0, 0, 68, 20);
        contentPane.add(btnBack);

        // Delete button
        JButton btnDelete = new JButton("DELETE");
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String itemToDelete = (String) tableModel.getValueAt(selectedRow, 0);
                    deleteFromDatabase(itemToDelete);
                }
            }
        });
        btnDelete.setBounds(694, 157, 89, 23);
        contentPane.add(btnDelete);

        ListSelectionModel selectionModel = table.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();

                    if (selectedRow != -1) {
                        String crc = (String) tableModel.getValueAt(selectedRow, 1);
                        String cfn = (String) tableModel.getValueAt(selectedRow, 2);

                        textField.setText(crc);
                        textField_1.setText(cfn);
                    }
                }
            }
        });
    }

    private void displayRegisteredItems() {
        try {
            String sql = "SELECT Year, Sem, Id FROM dbyrsem";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            tableModel.setRowCount(0);
            int studentCount = 0;

            while (resultSet.next()) {
            	String cc = resultSet.getString("Id");
                String crc = resultSet.getString("Year");
                String cfn = resultSet.getString("Sem");
                

                tableModel.addRow(new Object[] { cc, crc, cfn });
                studentCount++;
            }

            lblNewLabel_5.setText(Integer.toString(studentCount));

            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void saveChangesToDatabase() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String newcrc = textField.getText();
            String newcfn = textField_1.getText();
            String itemToUpdate = (String) tableModel.getValueAt(selectedRow, 0); // Change index to 0 for course code

            // Check if text fields are disabled
            if (!textField.isEnabled() || !textField_1.isEnabled()) {
                JOptionPane.showMessageDialog(null, "Please enable the fields before saving changes.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check if text fields are empty
            if (newcrc.isEmpty() || newcfn.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields before saving changes.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Ask for confirmation
            int confirmation = JOptionPane.showConfirmDialog(null, "Are you sure you want to update this record?", "Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirmation == JOptionPane.YES_OPTION) {
                try {
                    String updateSql = "UPDATE dbyrsem SET Year = ?, Sem = ? WHERE Year = ?";
                    PreparedStatement updateStatement = conn.prepareStatement(updateSql);
                    updateStatement.setString(1, newcrc);
                    updateStatement.setString(2, newcfn);
                    updateStatement.setString(3, itemToUpdate);

                    int updatedRows = updateStatement.executeUpdate();

                    if (updatedRows != 0) {
                        JOptionPane.showMessageDialog(null, "Failed to save changes to the database.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Changes saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

                        tableModel.setValueAt(newcrc, selectedRow, 1); // Change index to 0 for course code
                        tableModel.setValueAt(newcfn, selectedRow, 2);

                        textField.setText("");
                        textField_1.setText("");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            } else if (confirmation == JOptionPane.NO_OPTION) {
            	 textField.setText("");
                 textField_1.setText("");
            }
        }
    }

    private void deleteFromDatabase(String courseCode) {
    	
    
  	 int confirmationn = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this record?", "Confirmation", JOptionPane.YES_NO_OPTION);
     if (confirmationn == JOptionPane.YES_OPTION) {
        try {
            String deleteSql = "DELETE FROM dbyrsem WHERE Id = ?";
            PreparedStatement deleteStatement = conn.prepareStatement(deleteSql);
            deleteStatement.setString(1, courseCode);

            int deletedRows = deleteStatement.executeUpdate();

            if (deletedRows > 0) {
                // Successful deletion
                JOptionPane.showMessageDialog(null, "Row deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

                // Remove the row from the JTable
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    tableModel.removeRow(selectedRow);
                }
                // Update the total record count label
                lblNewLabel_5.setText(String.valueOf(tableModel.getRowCount()));
                textField.setText("");
                textField_1.setText("");
            } else {
                // Handle deletion failure
                JOptionPane.showMessageDialog(null, "Failed to delete the row.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            deleteStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
}