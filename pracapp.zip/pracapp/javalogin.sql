-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2023 at 04:29 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `javalogin`
--

-- --------------------------------------------------------

--
-- Table structure for table `itemngmnt`
--

CREATE TABLE `itemngmnt` (
  `Item` varchar(500) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `Quantity` float NOT NULL,
  `Price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itemngmnt`
--

INSERT INTO `itemngmnt` (`Item`, `Category`, `Description`, `Quantity`, `Price`) VALUES
('Flashdrives', 'Hardware', 'Kingston Brand 32GB', 10000, 780),
('Microsoft Office2023', 'Software', 'Windows 12 Supported', 20, 5400),
('Smart Phone', 'Hardware', 'Android 14', 2, 500),
('Wireless Mouse', 'Hardware', 'With RGB Color Lighting', 2, 200);

-- --------------------------------------------------------

--
-- Table structure for table `logininfo`
--

CREATE TABLE `logininfo` (
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logininfo`
--

INSERT INTO `logininfo` (`username`, `password`, `fullname`, `position`) VALUES
('test', '123', 'hahe', 1),
('castroluther', '321', 'hehe', 0),
('java', '123', 'javaprogramming', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
