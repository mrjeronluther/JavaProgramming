package pracapp;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ModifUser extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;
    private Connection conn;
    private JButton btnSaveChanges;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;
    private JButton btnDeleteUser;
    private JButton btnNewButton;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ModifUser frame = new ModifUser();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public ModifUser() {
        setResizable(false);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setBounds(100, 100, 706, 482);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblRegisteredUsers = new JLabel("REGISTERED USERS");
        lblRegisteredUsers.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblRegisteredUsers.setBounds(293, 0, 195, 31);
        contentPane.add(lblRegisteredUsers);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 53, 670, 248);
        contentPane.add(scrollPane);

        table = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        scrollPane.setViewportView(table);


        // Initialize the table model
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Username");
        tableModel.addColumn("Password");
        tableModel.addColumn("Full Name");
        tableModel.addColumn("Position");
        table.setModel(tableModel);

        // Add a ListSelectionListener to detect row selection
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        // Populate the text fields with data from the selected row
                        textField.setText((String) tableModel.getValueAt(selectedRow, 0));
                        textField_1.setText((String) tableModel.getValueAt(selectedRow, 1));
                        textField_2.setText((String) tableModel.getValueAt(selectedRow, 2));
                        textField_3.setText((String) tableModel.getValueAt(selectedRow, 3));
                    }
                }
            }
        });

        btnSaveChanges = new JButton("SAVE CHANGES");
        btnSaveChanges.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (textField.getText().isEmpty() || textField_1.getText().isEmpty() || textField_2.getText().isEmpty() || textField_3.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields before saving.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to save the changes?", "Confirm Save", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        saveChangesToDatabase();
                    }
                }
            }
        });

        btnSaveChanges.setBounds(293, 401, 135, 31);
        contentPane.add(btnSaveChanges);

        textField = new JTextField();
        textField.setBounds(10, 333, 157, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(177, 333, 158, 20);
        contentPane.add(textField_1);

        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(345, 333, 158, 20);
        contentPane.add(textField_2);

        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(513, 333, 157, 20);
        contentPane.add(textField_3);
        
        btnDeleteUser = new JButton("DELETE USER");
        btnDeleteUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String usernameToDelete = (String) tableModel.getValueAt(selectedRow, 0);
                    int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the selected user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        deleteFromDatabase(usernameToDelete);
                      
                        textField.setText("");
                        textField_1.setText("");
                        textField_2.setText("");
                        textField_3.setText("");
                        tableModel.removeRow(selectedRow);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a user to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnDeleteUser.setBounds(545, 405, 135, 31);
        contentPane.add(btnDeleteUser);
        
        JLabel lblNewLabel = new JLabel("EDIT USER BELOW");
        lblNewLabel.setBounds(10, 308, 167, 14);
        contentPane.add(lblNewLabel);
        
        JLabel lblSelectTheUser = new JLabel("SELECT THE ROW TO EDIT OR DELETE");
        lblSelectTheUser.setBounds(10, 33, 243, 14);
        contentPane.add(lblSelectTheUser);
        
        btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		USERRegistration frame = new USERRegistration();
                frame.setVisible(true);
                dispose();
        	}
        });
        btnNewButton.setBounds(0, -1, 69, 23);
        contentPane.add(btnNewButton);

        // Initialize the database connection
        initializeDatabaseConnection();

        // Fetch and display registered users
        displayRegisteredUsers();
    }

    private void initializeDatabaseConnection() {
        String url = "jdbc:mysql://127.0.0.1:3306/javalogin";
        String user = "root"; 
        String password = ""; 

        try {
            conn = DriverManager.getConnection(url, user, password);
            if (conn != null) {
                System.out.println("Connected to the database!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void displayRegisteredUsers() {
        try {
            String sql = "SELECT username, password, fullname, position FROM logininfo";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String fullname = resultSet.getString("fullname");
                String position = resultSet.getString("position");

                tableModel.addRow(new Object[]{username, password, fullname, position});
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void saveChangesToDatabase() {
        try {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                String newUsername = textField.getText();
                String newPassword = textField_1.getText();
                String newFullname = textField_2.getText();
                String newPosition = textField_3.getText();

                String usernameToUpdate = (String) tableModel.getValueAt(selectedRow, 0);

                // Update user information in the database
                String updateSql = "UPDATE logininfo SET username = ?, password = ?, fullname = ?, position = ? WHERE username = ?";
                PreparedStatement updateStatement = conn.prepareStatement(updateSql);
                updateStatement.setString(1, newUsername);
                updateStatement.setString(2, newPassword);
                updateStatement.setString(3, newFullname);
                updateStatement.setString(4, newPosition);
                updateStatement.setString(5, usernameToUpdate);

                int updatedRows = updateStatement.executeUpdate();

                if (updatedRows != 1) {
                    // If an update fails, show an error message
                    JOptionPane.showMessageDialog(null, "Failed to save changes to the database.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Update the table with the new values
                tableModel.setValueAt(newUsername, selectedRow, 0);
                tableModel.setValueAt(newPassword, selectedRow, 1);
                tableModel.setValueAt(newFullname, selectedRow, 2);
                tableModel.setValueAt(newPosition, selectedRow, 3);

                // If all updates are successful
                JOptionPane.showMessageDialog(null, "Changes saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

                textField.setText("");      
                textField_1.setText("");    
                textField_2.setText("");    
                textField_3.setText("");    
		       }
		    }   catch (SQLException ex) {
		            ex.printStackTrace();
      }	
   }

    private void deleteFromDatabase(String username) {
        try {
            String deleteSql = "DELETE FROM logininfo WHERE username = ?";
            PreparedStatement deleteStatement = conn.prepareStatement(deleteSql);
            deleteStatement.setString(1, username);
            int deletedRows = deleteStatement.executeUpdate();

            if (deletedRows != 1) {
                // Handle the case where the user was not deleted successfully
                JOptionPane.showMessageDialog(null, "Failed to delete user from the database.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Deletion was successful
                JOptionPane.showMessageDialog(null, "User deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}