package pracapp;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class indeex extends JFrame {

    private JPanel contentPane;
    private JPasswordField passwordField;
    private JTextField usernameTextField;
    private JLabel lblNewLabel_2;

    private static final String VALID_USERNAME[] = {"Jeron"};
    private static final String VALID_PASSWORD[] = {"Luther"};

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    indeex frame = new indeex();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public indeex() {
        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Luther\\eclipse-workspace\\MyApp\\src\\appnew\\icon.png"));
        setResizable(false);
        setTitle("Welcome");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("LOGIN ");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        lblNewLabel.setBounds(188, 26, 65, 34);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("USERNAME:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1.setBounds(58, 105, 97, 14);
        contentPane.add(lblNewLabel_1);

        
        usernameTextField = new JTextField();
        usernameTextField.setBounds(150, 103, 175, 20);
        contentPane.add(usernameTextField);
        usernameTextField.setColumns(10);

        // Add a JLabel for error message
        lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 10));
        lblNewLabel_2.setForeground(Color.RED); // Set text color to red for error message
        lblNewLabel_2.setBounds(150, 120, 223, 14);
        contentPane.add(lblNewLabel_2);

        usernameTextField.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '\b' ||  c == ' ' || c == '.' || c == '#')) {
                    e.consume(); // Prevent the character from being entered
                    lblNewLabel_2.setText("Invalid Key"); // Set error message
                } else {
                    lblNewLabel_2.setText(""); // Clear error message if input is valid
                }
            }
        });

        JLabel lblNewLabel_1_1 = new JLabel("PASSWORD:");
        lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
        lblNewLabel_1_1.setBounds(58, 157, 97, 14);
        contentPane.add(lblNewLabel_1_1);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 157, 175, 20);
        contentPane.add(passwordField);

        JButton btnNewButton = new JButton("ENTER");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameTextField.getText();
                String password = new String(passwordField.getPassword());

                if (isValidUser(username, password)) {
                    openNextWindow();
                    
                } else {
                    // Display an error message in a dialog box
                    JOptionPane.showMessageDialog(usernameTextField, "Please check your Username and Password.", "Account doesn't exist", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        
        
        btnNewButton.setBounds(186, 215, 89, 23);
        contentPane.add(btnNewButton);
    }

    private boolean isValidUser(String username, String password) {
        for (int i = 0; i < VALID_USERNAME.length; i++) {
            if (username.equals(VALID_USERNAME[i]) && password.equals(VALID_PASSWORD[i])) {
                return true;
            }
        }
        return false;
    }
    private void openNextWindow() {
        body frame = new body();
        frame.setVisible(true);
        dispose(); // Close the current login window
    }
}
