package pracapp;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Login extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private Connection conn;
    

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Login frame = new Login();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Login() {
    	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Login");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel.setBounds(187, 36, 74, 23);
        contentPane.add(lblNewLabel);


        textField = new JTextField();
        textField.setBounds(105, 85, 230, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setColumns(10);
        textField_1.setBounds(105, 149, 230, 20);
        contentPane.add(textField_1);

        JLabel lblNewLabel_1 = new JLabel("USERNAME:");
        lblNewLabel_1.setBounds(10, 88, 85, 14);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_1_1 = new JLabel("PASSWORD:");
        lblNewLabel_1_1.setBounds(10, 152, 85, 14);
        contentPane.add(lblNewLabel_1_1);

        JButton btnNewButton = new JButton("Enter");
        btnNewButton.setBounds(172, 214, 89, 23);
        contentPane.add(btnNewButton);

       
        btnNewButton.addActionListener(e -> {
            String username = textField.getText();
            String password = textField_1.getText();

            try {
                String sql = "SELECT * FROM logininfo WHERE username = ? AND password = ?";
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, password);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    int userPosition = resultSet.getInt("position");
                    
                    if (userPosition == 1) {
                        // Admin login successful
                        JOptionPane.showMessageDialog(null, "Admin Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);

                        // Open the admin page 
                        ADMINPage adminFrame = new ADMINPage();
                        adminFrame.setVisible(true);
                        dispose();
                      
                    } else {
                        // Regular user login successful
                        JOptionPane.showMessageDialog(null, "User Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);

                        // Open the user page
                        USERPage frame = new USERPage();
    					frame.setVisible(true);
    					dispose();
                        
                    }
                 
                } else {
                    
                    JOptionPane.showMessageDialog(null, "Login Failed. Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
                    textField.setText("");    
                    textField_1.setText(""); 
                }

                // Close resources
                resultSet.close();
                preparedStatement.close();
                
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        // Initialize the database connection
        initializeDatabaseConnection();
    }

    private void initializeDatabaseConnection() {
        String url = "jdbc:mysql://127.0.0.1:3306/javalogin";
        String user = "root"; 
        String password = ""; 

        try {
            conn = DriverManager.getConnection(url, user, password);
            if (conn != null) {
                System.out.println("Connected to the database!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
