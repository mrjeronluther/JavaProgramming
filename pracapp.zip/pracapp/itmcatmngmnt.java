package pracapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class itmcatmngmnt extends JFrame{

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;
    private JTextField txtSearch;
    private JLabel lblItem;
    private JTextField textField_1;
    private JLabel lblCategory;
    private JTextField textField_2;
    private JButton btnAdd;
    private JButton btnModify;
    private JButton btnDelete;
    private JLabel lblDescription;
    private JTextField textField_3;
    private JLabel lblQuantity;
    private JTextField textField_4;
    private JLabel lblPrice;
    private JTextField textField_5;
    private DefaultTableModel tableModel;
    private Connection conn;
    private JTable table;
    private JLabel lblNewLabel;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private JTextField textField;
    private JTextField textField_6;
    private JTextField textField_7;
    private JTextField textField_8;
    private JTextField textField_9;
    private JButton btnNewButton;
  

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	itmcatmngmnt frame = new itmcatmngmnt();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public itmcatmngmnt() {
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 729, 482);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblCategoryManagement = new JLabel("ITEM/CATEGORY MANAGEMENT");
        lblCategoryManagement.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblCategoryManagement.setBounds(218, 29, 301, 48);
        contentPane.add(lblCategoryManagement);

        txtSearch = new JTextField();
        txtSearch.setBounds(435, 87, 268, 20);
        contentPane.add(txtSearch);
        txtSearch.setColumns(10);

        lblItem = new JLabel("ITEM:");
        lblItem.setBounds(20, 135, 46, 14);
        contentPane.add(lblItem);

        textField_1 = new JTextField();
        textField_1.setBounds(119, 132, 154, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        lblCategory = new JLabel("CATEGORY:");
        lblCategory.setBounds(20, 172, 78, 14);
        contentPane.add(lblCategory);

        textField_2 = new JTextField();
        textField_2.setColumns(10);
        textField_2.setBounds(119, 169, 154, 20);
        contentPane.add(textField_2);

        btnAdd = new JButton("ADD");
        btnAdd.setBounds(20, 364, 89, 23);
        contentPane.add(btnAdd);
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String Item = textField_1.getText();
                String Category = textField_2.getText();
                String Description = textField_3.getText();
                String Quantity = textField_4.getText();
                String Price = textField_5.getText();

                if (Item.isEmpty() || Category.isEmpty() || Description.isEmpty() || Quantity.isEmpty() || Price.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields before adding an item.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    try {
                        String url = "jdbc:mysql://127.0.0.1:3306/javalogin";
                        String user = "root";
                        String password = "";

                        conn = DriverManager.getConnection(url, user, password);

                        String sql = "INSERT INTO itemngmnt (Item, Category, Description, Quantity, Price) VALUES (?, ?, ?, ?, ?)";
                        PreparedStatement preparedStatement = conn.prepareStatement(sql);
                        preparedStatement.setString(1, Item);
                        preparedStatement.setString(2, Category);
                        preparedStatement.setString(3, Description);
                        preparedStatement.setString(4, Quantity);
                        preparedStatement.setString(5, Price);

                        int rowsAffected = preparedStatement.executeUpdate();
                        if (rowsAffected > 0) {
                            JOptionPane.showMessageDialog(null, "Addition of Item Success", "SUCCESS", JOptionPane.INFORMATION_MESSAGE);
                            textField_1.setText("");
                            textField_2.setText("");
                            textField_3.setText("");
                            textField_4.setText("");
                            textField_5.setText("");
                        } else {
                            System.out.println("Failed to add item to the database.");
                        }

                        preparedStatement.close();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                    // Fetch and display registered items or categories
                    displayRegisteredItems();
                }
            }
        });

        btnModify = new JButton("SAVE");
        btnModify.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 if (textField.getText().isEmpty() || textField_6.getText().isEmpty() || textField_7.getText().isEmpty() || textField_8.getText().isEmpty() || textField_9.getText().isEmpty()) {
                     JOptionPane.showMessageDialog(null, "Please fill in all fields before saving.", "Error", JOptionPane.ERROR_MESSAGE);
                 } else {
                     int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to save the changes?", "Confirm Save", JOptionPane.YES_NO_OPTION);
                     if (confirm == JOptionPane.YES_OPTION) {
                         saveChangesToDatabase();
                     }
                 }
        	}
        	
        });
        btnModify.setBounds(293, 409, 89, 23);
        contentPane.add(btnModify);

        btnDelete = new JButton("DELETE");
        btnDelete.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String ItemToDelete = (String) tableModel.getValueAt(selectedRow, 0);
                    int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete the selected user?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        deleteFromDatabase(ItemToDelete);
                      
                        textField.setText("");
                        textField_6.setText("");
                        textField_7.setText("");
                        textField_8.setText("");
                        textField_9.setText("");
                        tableModel.removeRow(selectedRow);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a Item to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                
        		
                }
        	}
        });
        
        
        btnDelete.setBounds(541, 409, 89, 23);
        contentPane.add(btnDelete);

        lblDescription = new JLabel("DESCRIPTION:");
        lblDescription.setBounds(20, 210, 78, 14);
        contentPane.add(lblDescription);

        textField_3 = new JTextField();
        textField_3.setColumns(10);
        textField_3.setBounds(119, 207, 154, 34);
        contentPane.add(textField_3);

        lblQuantity = new JLabel("QUANTITY:");
        lblQuantity.setBounds(20, 255, 78, 14);
        contentPane.add(lblQuantity);

        textField_4 = new JTextField();
        textField_4.setColumns(10);
        textField_4.setBounds(119, 252, 154, 20);
        contentPane.add(textField_4);

        lblPrice = new JLabel("PRICE:");
        lblPrice.setBounds(20, 286, 78, 14);
        contentPane.add(lblPrice);

        textField_5 = new JTextField();
        textField_5.setColumns(10);
        textField_5.setBounds(119, 283, 154, 20);
        contentPane.add(textField_5);

        // Create a JScrollPane to hold the JTable
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(293, 112, 420, 221);
        contentPane.add(scrollPane);

        table = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        scrollPane.setViewportView(table);

        // Create the JTable and set the table model
        tableModel = new DefaultTableModel();
        table.setModel(tableModel); // Set the table model to the existing table

        // Initialize the table model
        tableModel.addColumn("Item");
        tableModel.addColumn("Category");
        tableModel.addColumn("Description");
        tableModel.addColumn("Quantity");
        tableModel.addColumn("Price");
        // Create a TableRowSorter for the tableModel
        rowSorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(rowSorter);

        lblNewLabel = new JLabel("SEARCH HERE:");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
        lblNewLabel.setBounds(355, 90, 73, 14);
        contentPane.add(lblNewLabel);

        // Add a DocumentListener to the search bar's document
        txtSearch.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                filterItems();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                filterItems();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                filterItems();
            }

            private void filterItems() {
                String text = txtSearch.getText();
                if (text.trim().isEmpty()) {
                    // If the search text is empty, show all rows
                    rowSorter.setRowFilter(null);
                } else {
                    // Use a RowFilter to show only rows that match the search text
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }
        });

        // Establish a database connection
        try {
            String url = "jdbc:mysql://127.0.0.1:3306/javalogin";
            String user = "root";
            String password = "";
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        displayRegisteredItems();
    }


    private void displayRegisteredItems() {

        try {
            String sql = "SELECT Item, Category, Description, Quantity, Price FROM itemngmnt";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            tableModel.setRowCount(0);

            while (resultSet.next()) {
                String item = resultSet.getString("Item");
                String category = resultSet.getString("Category");
                String description = resultSet.getString("Description");
                String quantity = resultSet.getString("Quantity");
                String price = resultSet.getString("Price");

                tableModel.addRow(new Object[]{item, category, description, quantity, price});
            }

            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        textField = new JTextField();
        textField.setBounds(293, 344, 135, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_6 = new JTextField();
        textField_6.setColumns(10);
        textField_6.setBounds(435, 344, 135, 20);
        contentPane.add(textField_6);

        textField_7 = new JTextField();
        textField_7.setColumns(10);
        textField_7.setBounds(578, 344, 135, 20);
        contentPane.add(textField_7);

        textField_8 = new JTextField();
        textField_8.setColumns(10);
        textField_8.setBounds(367, 375, 135, 20);
        contentPane.add(textField_8);

        textField_9 = new JTextField();
        textField_9.setColumns(10);
        textField_9.setBounds(512, 375, 135, 20);
        contentPane.add(textField_9);
        
        
        
        
    
        btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	USERPage frame = new USERPage();
				frame.setVisible(true);
                dispose();
            }
        });
             
    
        
        btnNewButton.setBounds(0, 0, 69, 23);
        contentPane.add(btnNewButton);

        // Add a ListSelectionListener to the table
        ListSelectionModel selectionModel = table.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        // Retrieve data from the selected row
                        String item = (String) tableModel.getValueAt(selectedRow, 0);
                        String category = (String) tableModel.getValueAt(selectedRow, 1);
                        String description = (String) tableModel.getValueAt(selectedRow, 2);
                        String quantity = (String) tableModel.getValueAt(selectedRow, 3);
                        String price = (String) tableModel.getValueAt(selectedRow, 4);

                        // Populate the text fields with the selected data
                        textField.setText(item);
                        textField_6.setText(category);
                        textField_7.setText(description);
                        textField_8.setText(quantity);
                        textField_9.setText(price);
                    }
                }
            }
        });
    }

        public void displayRegisteredItems1() {
            try {
                String sql = "SELECT Item, Category, Description, Quantity, Price FROM itemngmnt";
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    String Item = resultSet.getString("Item");
                    String Category = resultSet.getString("Category");
                    String Description = resultSet.getString("Description");
                    String Quantity = resultSet.getString("Quantity");
                    String Price = resultSet.getString("Price");

                    tableModel.addRow(new Object[]{Item, Category, Description, Quantity, Price});
                }

                // Close resources
                resultSet.close();
                preparedStatement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void saveChangesToDatabase() {
            try {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    String newitem = textField.getText();
                    String newcat = textField_6.getText();
                    String newdes = textField_7.getText();
                    String newqty = textField_8.getText();
                    String newprc = textField_9.getText();

                    String ItemToUpdate = (String) tableModel.getValueAt(selectedRow, 0);

                    // Update user information in the database
                    String updateSql = "UPDATE itemngmnt SET Item = ?, Category = ?, Description = ?, Quantity = ?, Price = ? WHERE Item = ?";
                    PreparedStatement updateStatement = conn.prepareStatement(updateSql);
                    updateStatement.setString(1, newitem);
                    updateStatement.setString(2, newcat);
                    updateStatement.setString(3, newdes);
                    updateStatement.setString(4, newqty);
                    updateStatement.setString(5, newprc);
                    updateStatement.setString(6, ItemToUpdate);

                    int updatedRows = updateStatement.executeUpdate();

                    if (updatedRows != 1) {
                        // If an update fails, show an error message
                        JOptionPane.showMessageDialog(null, "Failed to save changes to the database.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }


        
                // Update the table with the new values
                tableModel.setValueAt(newitem, selectedRow, 0);
                tableModel.setValueAt(newcat, selectedRow, 1);
                tableModel.setValueAt(newdes, selectedRow, 2);
                tableModel.setValueAt(newqty, selectedRow, 3);
                tableModel.setValueAt(newprc, selectedRow, 4);

                // If all updates are successful
                JOptionPane.showMessageDialog(null, "Changes saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

              
                textField.setText("");    
                textField_6.setText("");    
                textField_7.setText("");    
                textField_8.setText("");
                textField_9.setText("");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public static void main1(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    itemandcategorymanagement frame = new itemandcategorymanagement();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

private void deleteFromDatabase(String Item) {
    try {
        String deleteSql = "DELETE FROM itemngmnt WHERE Item = ?";
        PreparedStatement deleteStatement = conn.prepareStatement(deleteSql);
        deleteStatement.setString(1, Item);
        int deletedRows = deleteStatement.executeUpdate();

        if (deletedRows != 1) {
            // Handle the case where the user was not deleted successfully
            JOptionPane.showMessageDialog(null, "Failed to delete user from the database.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            // Deletion was successful
            JOptionPane.showMessageDialog(null, "User deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    
}
}




       
