package pracapp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JList;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.SwingConstants;

public class sampleusermanagement extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField txtUser;
	private JTextField txtPsswrd;
	private JTextField txtJeronLutherCastro;
	private JTextField txtuserid;
	private JTextField txtUsernamePasswordFullname;
	private JTextField txtSearch;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					sampleusermanagement frame = new sampleusermanagement();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public sampleusermanagement() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 745, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("USER MANAGEMENT");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblNewLabel.setBounds(281, 11, 210, 48);
		contentPane.add(lblNewLabel);
		
		JButton btnCategoryManagement = new JButton("DELETE");
		btnCategoryManagement.setBounds(105, 410, 71, 23);
		contentPane.add(btnCategoryManagement);
		
		JLabel lblNewLabel_1 = new JLabel("USERNAME:");
		lblNewLabel_1.setBounds(21, 155, 63, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("PASSWORD:");
		lblNewLabel_1_1.setBounds(21, 193, 63, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("FULLNAME:");
		lblNewLabel_1_1_1.setBounds(21, 234, 63, 14);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("ID NUMBER:");
		lblNewLabel_1_1_1_1.setBounds(21, 273, 63, 14);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		JButton btnEdit = new JButton("EDIT");
		btnEdit.setBounds(147, 375, 71, 23);
		contentPane.add(btnEdit);
		
		JButton btnCategoryManagement_1 = new JButton("CREATE");
		btnCategoryManagement_1.setBounds(66, 375, 71, 23);
		contentPane.add(btnCategoryManagement_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(94, 155, 158, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(94, 190, 158, 20);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(94, 231, 158, 20);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(94, 270, 158, 20);
		contentPane.add(textField_4);
		
		txtUser = new JTextField();
		txtUser.setText("user012");
		txtUser.setBackground(new Color(192, 192, 192));
		txtUser.setBounds(278, 165, 86, 20);
		contentPane.add(txtUser);
		txtUser.setColumns(10);
		
		txtPsswrd = new JTextField();
		txtPsswrd.setText("P@sSw0rd2212");
		txtPsswrd.setColumns(10);
		txtPsswrd.setBackground(Color.LIGHT_GRAY);
		txtPsswrd.setBounds(365, 165, 86, 20);
		contentPane.add(txtPsswrd);
		
		txtJeronLutherCastro = new JTextField();
		txtJeronLutherCastro.setHorizontalAlignment(SwingConstants.CENTER);
		txtJeronLutherCastro.setText("JERON LUTHER CASTRO");
		txtJeronLutherCastro.setColumns(10);
		txtJeronLutherCastro.setBackground(Color.LIGHT_GRAY);
		txtJeronLutherCastro.setBounds(452, 165, 139, 20);
		contentPane.add(txtJeronLutherCastro);
		
		txtuserid = new JTextField();
		txtuserid.setText("2023-userid22");
		txtuserid.setColumns(10);
		txtuserid.setBackground(Color.LIGHT_GRAY);
		txtuserid.setBounds(592, 165, 79, 20);
		contentPane.add(txtuserid);
		
		textField = new JTextField();
		textField.setBounds(275, 155, 400, 250);
		contentPane.add(textField);
		textField.setColumns(10);
		
		txtUsernamePasswordFullname = new JTextField();
		txtUsernamePasswordFullname.setForeground(new Color(192, 192, 192));
		txtUsernamePasswordFullname.setFont(new Font("Tahoma", Font.BOLD, 10));
		txtUsernamePasswordFullname.setBackground(new Color(128, 128, 128));
		txtUsernamePasswordFullname.setText("     USERNAME           PASSWORD                 FULLNAME                  ID NUMBER");
		txtUsernamePasswordFullname.setBounds(275, 127, 400, 20);
		contentPane.add(txtUsernamePasswordFullname);
		txtUsernamePasswordFullname.setColumns(10);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setBounds(10, 11, 71, 23);
		contentPane.add(btnBack);
		
		txtSearch = new JTextField();
		txtSearch.setText("SEARCH ");
		txtSearch.setBounds(281, 96, 188, 20);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
	}
}
