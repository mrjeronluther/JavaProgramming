package pracapp;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.Font;

import java.awt.EventQueue;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;

public class reportpage extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    reportpage frame = new reportpage();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public reportpage() {
        setBounds(100, 100, 683, 491);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblReport = new JLabel("REPORT");
        lblReport.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        lblReport.setBounds(297, 11, 81, 48);
        contentPane.add(lblReport);

        JButton btnExportData = new JButton("EXPORT DATA");
        btnExportData.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                exportDataToExcel();
            }
        });
        btnExportData.setBounds(227, 288, 199, 23);
        contentPane.add(btnExportData);
    }

    private void exportDataToExcel() {
        try {
            // Create a new workbook
            Workbook workbook = new HSSFWorkbook();
            Sheet sheet = workbook.createSheet("Data Report");

            // Create header row
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Column 1");
            headerRow.createCell(1).setCellValue("Column 2");
            headerRow.createCell(2).setCellValue("Column 3");

            // You can replace the sample data with your own database retrieval
            // For example:
            String sql = "SELECT Item, Category, Description, Quantity, Price FROM itemngmnt";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();

            int rowNumber = 1;
            while (resultSet.next()) {
                Row dataRow = sheet.createRow(rowNumber);
                dataRow.createCell(0).setCellValue(resultSet.getString("Item"));
                dataRow.createCell(1).setCellValue(resultSet.getString("Category"));
                dataRow.createCell(2).setCellValue(resultSet.getString("Description"));
                dataRow.createCell(3).setCellValue(resultSet.getString("Quantity"));
                dataRow.createCell(4).setCellValue(resultSet.getString("Price"));
                rowNumber++;
            }

            // Save the workbook to a file
            String fileName = "data_report_" + new Date().getTime() + ".xls";
            try (FileOutputStream fileOut = new FileOutputStream(fileName)) {
                workbook.write(fileOut);
                JOptionPane.showMessageDialog(null, "Data exported to " + fileName, "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
